// DaFlip host test: loads the .so like the MPC does and checks the plugin as a whole: the parameter interface, presets,
// read-outs, monitoring transparency (bit-exact at every rate and block size, separate and in-place buffers), the features
// through the real parameters, latency reporting, bypass, sessions (rate changes, two instances, open/close churn) and a
// random-use soak.   Usage: host_test plugin.so [soak-minutes]
#include "vst2.h"
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <dlfcn.h>
#include <string>
#include <vector>

static int fails = 0, checks = 0;
#define CHECK(cond, ...) do { ++checks; if (! (cond)) { ++fails; std::printf ("  FAIL: "); std::printf (__VA_ARGS__); std::printf ("\n"); } \
                              else { std::printf ("  ok:   "); std::printf (__VA_ARGS__); std::printf ("\n"); } } while (0)
typedef AEffect* (*MainFn) (audioMasterCallback);
typedef const char* (*KeyFn) (int);
static MainFn main_; static KeyFn keyOf;
static int automates = 0;
static intptr_t host (AEffect*, int32_t op, int32_t, intptr_t, void*, float) { if (op == audioMasterAutomate) ++automates; return op == 1 ? 2400 : 0; }

struct Inst
{
    AEffect* fx = nullptr; float sr = 44100;
    intptr_t D (int op, int i = 0, intptr_t v = 0, void* p = nullptr, float o = 0) { return fx->dispatcher (fx, op, i, v, p, o); }
    int idx (const char* k) { for (int i = 0; i < fx->numParams; ++i) if (std::strcmp (keyOf (i), k) == 0) return i; std::printf ("no param %s\n", k); std::exit (2); }
    void set (const char* k, float n) { fx->setParameter (fx, idx (k), n); }
    float get (const char* k) { return fx->getParameter (fx, idx (k)); }
    std::string text (const char* k) { char b[256] = {}; D (effGetParamDisplay, idx (k), 0, b); return b; }
    std::vector<float> defaults;
    void open (float rate)
    {
        fx = main_ (host); sr = rate;
        D (effOpen); D (effSetSampleRate, 0, 0, nullptr, rate); D (effSetBlockSize, 0, 4096); D (effMainsChanged, 0, 1);
        defaults.resize ((size_t) fx->numParams);
        for (int i = 0; i < fx->numParams; ++i) defaults[(size_t) i] = fx->getParameter (fx, i);
    }
    void close() { D (effMainsChanged, 0, 0); D (effClose); fx = nullptr; }
    void restore() { for (int i = 0; i < fx->numParams; ++i) { const char* k = keyOf (i); if (std::strcmp (k, "info") && std::strcmp (k, "corr") && std::strcmp (k, "level")) fx->setParameter (fx, i, defaults[(size_t) i]); } }
};
struct Runner
{
    Inst& in; uint32_t s = 12345; double t = 0; bool inPlace = false; int block = 256; float peak = 0; long nonFinite = 0;
    std::vector<float> L, R, oL, oR, lastL, lastR, lastInL, lastInR;
    explicit Runner (Inst& i) : in (i) { L.resize (8192); R.resize (8192); oL.resize (8192); oR.resize (8192); }
    float noise() { s = s * 1664525u + 1013904223u; return (float) ((int32_t) s >> 8) / 8388608.f; }
    // mode 0: different noise + tones on L and R; 1: L == R; 2: R = -L; 3: silence
    long run (double sec, bool count = true, int mode = 0, float amp = 0.45f)
    {
        long diff = 0; long left = (long) (sec * in.sr);
        lastL.clear(); lastR.clear(); lastInL.clear(); lastInR.clear();
        while (left > 0)
        {
            const int n = (int) (left < block ? left : block);
            for (int i = 0; i < n; ++i, t += 1.0)
            {
                const float a = amp * (0.6f * (float) std::sin (2 * M_PI * 220.0 * t / in.sr) + 0.4f * noise());
                const float b = amp * (0.6f * (float) std::sin (2 * M_PI * 330.0 * t / in.sr) + 0.4f * noise());
                L[i] = mode == 3 ? 0.f : a; R[i] = mode == 3 ? 0.f : (mode == 1 ? a : (mode == 2 ? -a : b));
            }
            std::vector<float> kL (L.begin(), L.begin() + n), kR (R.begin(), R.begin() + n);
            float* ins[2] { L.data(), R.data() };
            float* outs[2] { inPlace ? L.data() : oL.data(), inPlace ? R.data() : oR.data() };
            in.fx->processReplacing (in.fx, ins, outs, n);
            for (int i = 0; i < n; ++i)
            {
                const float a = outs[0][i], b = outs[1][i];
                if (! std::isfinite (a) || ! std::isfinite (b)) ++nonFinite;
                peak = std::fmax (peak, std::fmax (std::fabs (a), std::fabs (b)));
                if (count) { if (a != kL[(size_t) i]) ++diff; if (b != kR[(size_t) i]) ++diff; }
                lastL.push_back (a); lastR.push_back (b); lastInL.push_back (kL[(size_t) i]); lastInR.push_back (kR[(size_t) i]);
            }
            left -= n;
        }
        return diff;
    }
};
static bool has (const std::string& a, const char* b) { return a.find (b) != std::string::npos; }

static void testInterface()
{
    std::printf ("[plugin interface]\n");
    Inst in; in.open (44100);
    CHECK (in.fx->magic == kEffectMagic && in.fx->numInputs == 2 && in.fx->numOutputs == 2 && in.fx->uniqueID == 0x44464C50, "VST2 effect, stereo in/out, ID DFLP");
    char nm[64] = {}; in.D (effGetEffectName, 0, 0, nm); char vd[64] = {}; in.D (effGetVendorString, 0, 0, vd);
    CHECK (std::string (nm) == "DaFlip" && std::string (vd) == "ScratchLab", "name '%s' by '%s'", nm, vd);
    int badNames = 0, readouts = 0;
    for (int i = 0; i < in.fx->numParams; ++i)
    {
        char n[64] = {}, d[256] = {}; in.D (effGetParamName, i, 0, n); in.D (effGetParamDisplay, i, 0, d);
        if (! n[0] || ! d[0] || ! keyOf (i)[0]) ++badNames;
        const bool ro = ! std::strcmp (keyOf (i), "info") || ! std::strcmp (keyOf (i), "corr") || ! std::strcmp (keyOf (i), "level");
        if (in.D (effCanBeAutomated, i) == (ro ? 0 : 1)) ++readouts;
    }
    CHECK (badNames == 0 && readouts == in.fx->numParams, "%d parameters: names, displays, keys; read-outs not automatable", in.fx->numParams);
    CHECK (in.text ("width") == "100 %" && in.text ("gain") == "+0.0 dB" && in.text ("pan") == "C" && in.text ("basshz") == "120 Hz"
           && in.text ("isohi") == "20 kHz" && in.text ("inmode") == "Stereo" && in.text ("isomode") == "Off", "default displays (width %s, gain %s, pan %s, bass %s, high %s)",
           in.text ("width").c_str(), in.text ("gain").c_str(), in.text ("pan").c_str(), in.text ("basshz").c_str(), in.text ("isohi").c_str());
    in.set ("pan", 0.25f); in.set ("isopos", 0.8f); in.set ("gain", 0.f);
    CHECK (in.text ("pan") == "L 50" && in.text ("isopos") == "R 60" && in.text ("gain") == "-inf dB", "pan %s, position %s, gain at the bottom %s", in.text ("pan").c_str(), in.text ("isopos").c_str(), in.text ("gain").c_str());
    int presetsOk = 0;
    for (int p = 0; p < in.fx->numPrograms; ++p) { char pn[64] = {}; if (in.D (effGetProgramNameIndexed, p, 0, pn) == 1 && pn[0]) ++presetsOk; }
    in.D (effSetProgram, 0, 1);
    CHECK (presetsOk == in.fx->numPrograms && in.text ("inmode") == "Left" && in.text ("pan") == "C", "%d presets named; 'Left Channel Only' sets Input Left and resets the rest", presetsOk);
    in.close();
}

static void testMonitoring()
{
    std::printf ("[monitoring: everything off = output identical to input, both channels, no delay]\n");
    for (float rate : { 44100.f, 48000.f, 96000.f })
    {
        Inst in; in.open (rate); long diff = 0; int combos = 0;
        for (bool ip : { false, true }) for (int blk : { 1, 32, 64, 128, 256, 512, 1000, 1024, 4096 })
        { Runner r (in); r.inPlace = ip; r.block = blk; diff += r.run (blk == 1 ? 0.05 : 0.4); ++combos; }
        Runner r (in); const long sil = r.run (0.3, true, 3); const float pk = r.peak; const long fs = r.run (0.3, true, 0, 1.0f);
        CHECK (diff == 0 && sil == 0 && pk == 0.f && fs == 0 && in.fx->initialDelay == 0,
               "%.1f kHz: %d block sizes x separate/in-place, silence, full scale: %ld samples differ, delay %d", rate / 1000, combos / 2, diff + sil + fs, in.fx->initialDelay);
        in.close();
    }
}

static void testFeatures()
{
    std::printf ("[features through the real parameters; clean monitoring after each]\n");
    Inst in; in.open (44100); Runner r (in);
    r.run (1.0, false);
    auto clean = [&] (const char* what)
    {
        in.restore(); r.run (0.6, false);
        const long d = r.run (0.5);
        CHECK (d == 0 && in.fx->initialDelay == 0, "%s, then clean monitoring (%ld samples differ)", what, d);
    };
    in.set ("inmode", 1.f / 3.f); r.run (0.2, false);
    { bool same = true; for (size_t i = 0; i < r.lastL.size(); ++i) if (r.lastL[i] != r.lastR[i] || r.lastL[i] != r.lastInL[i]) same = false; CHECK (same, "Input LEFT: left on both sides"); }
    clean ("Input LEFT");
    in.set ("invr", 1.f); r.run (0.2, false);
    { bool ok = true; for (size_t i = 0; i < r.lastR.size(); ++i) if (r.lastR[i] != -r.lastInR[i]) ok = false; CHECK (ok, "PHASE R: right inverted"); }
    clean ("PHASE R");
    in.set ("mono", 1.f); r.run (0.2, false); r.run (0.2, false);
    { bool ok = true; for (size_t i = 0; i < r.lastR.size(); ++i) if (r.lastR[i] != r.lastL[i]) ok = false; CHECK (ok, "MONO: L == R"); }
    clean ("MONO");
    for (const char* k : { "msenc", "bassmono", "dc", "mute" }) { in.set (k, 1.f); r.run (0.3, false); clean (k); }
    in.set ("width", 1.f); r.run (0.3, false); clean ("WIDTH 200 %");
    in.set ("gain", (6.f + 60.f) / 84.f); r.run (0.3, false); clean ("GAIN +6 dB");
    in.set ("pan", 0.f); r.run (0.1, false); r.run (0.2, false);                 // past the 20 ms glide
    { float mx = 0; for (float x : r.lastR) mx = std::fmax (mx, std::fabs (x)); CHECK (mx == 0.f, "PAN L 100: right silent"); }
    clean ("PAN");
    for (float lv : { 1.f / 3.f, 2.f / 3.f, 1.f }) { in.set ("listen", lv); r.run (0.3, false); }
    clean ("LISTEN mid / side / bass");
    // the isolator: latency reported while it runs, gone after
    in.set ("isomode", 0.5f); in.set ("isopos", 0.f); r.run (0.5, false);
    CHECK (in.fx->initialDelay == 2048 && has (in.text ("info"), "ISOLATE L 100") && has (in.text ("info"), "46 ms delay"),
           "ISOLATE: delay %d reported, status '%s'", in.fx->initialDelay, in.text ("info").c_str());
    in.set ("isomode", 1.f); r.run (0.3, false);
    CHECK (has (in.text ("info"), "REMOVE"), "REMOVE: '%s'", in.text ("info").c_str());
    clean ("the pan isolator");
    // read-outs: correlation and phase warning
    Runner m (in); m.run (1.0, false, 1); r.run (0.2, false);
    automates = 0; m.run (2.0, false, 1);                                      // the meter averages over 300 ms
    CHECK (in.text ("corr") == "+1.00" && automates > 0, "correlation of identical channels: %s (sent to the screen)", in.text ("corr").c_str());
    m.run (2.0, false, 2);
    CHECK (in.text ("corr") == "-1.00" && has (in.text ("info"), "PHASE WARNING"), "inverted channels: %s, '%s'", in.text ("corr").c_str(), in.text ("info").c_str());
    in.set ("invr", 1.f); m.run (2.0, false, 2);
    CHECK (in.text ("corr") == "+1.00" && ! has (in.text ("info"), "PHASE WARNING"), "PHASE R fixes it: %s", in.text ("corr").c_str());
    in.restore(); m.run (1.0, false, 0);
    CHECK (has (in.text ("info"), "CORREL") && in.text ("level") != "-inf dB", "status '%s', level %s", in.text ("info").c_str(), in.text ("level").c_str());
    // presets
    for (int p = 0; p < in.fx->numPrograms; ++p) { in.D (effSetProgram, 0, p); r.run (0.2, false); }
    in.D (effSetProgram, 0, 0); clean ("every preset, back to Clean");
    // bypass, even while isolating
    in.set ("isomode", 0.5f); r.run (0.5, false); in.set ("bypass", 1.f); r.run (0.01, false);
    CHECK (r.run (0.5) == 0, "BYPASS while isolating: output == input at once");
    clean ("BYPASS off");
    in.close();
}

static void testSessions (double minutes)
{
    std::printf ("[sessions: rate changes, two instances, open / close churn, a %.0f-minute random-use soak]\n", minutes);
    {
        Inst in; in.open (44100); Runner r (in); bool ok = true;
        for (float rate : { 48000.f, 96000.f, 44100.f })
        {
            in.set ("isomode", 0.5f); r.run (0.3, false);
            in.D (effMainsChanged, 0, 0); in.D (effSetSampleRate, 0, 0, nullptr, rate); in.sr = rate; in.D (effMainsChanged, 0, 1);
            in.restore(); r.run (0.5, false); if (r.run (0.3) != 0) ok = false;
        }
        CHECK (ok && r.nonFinite == 0, "44.1 -> 48 -> 96 -> 44.1 kHz while isolating: clean after each");
        in.close();
    }
    {
        Inst a, b; a.open (48000); b.open (48000); Runner ra (a), rb (b); rb.s = 999;
        a.set ("isomode", 0.5f); a.set ("width", 0.f); long db = 0;
        for (int k = 0; k < 40; ++k) { ra.run (0.02, false); db += rb.run (0.02); }
        CHECK (db == 0, "two instances: one isolating, the other untouched (%ld differ)", db);
        a.close(); b.close();
    }
    {
        bool ok = true;
        for (int k = 0; k < 30; ++k) { Inst in; in.open (k % 2 ? 44100.f : 96000.f); Runner r (in); in.set ("isomode", 0.5f); r.run (0.1, false); if (r.nonFinite) ok = false; in.close(); }
        CHECK (ok, "30 open / use / close cycles");
    }
    {
        Inst in; in.open (48000); Runner r (in); uint32_t x = 31;
        auto rnd = [&] { x = x * 1103515245u + 12345u; return (x >> 8) & 0xFFFFFF; };
        std::vector<int> ps;
        for (int i = 0; i < in.fx->numParams; ++i) { const char* k = keyOf (i); if (std::strcmp (k, "info") && std::strcmp (k, "corr") && std::strcmp (k, "level") && std::strcmp (k, "gain")) ps.push_back (i); }
        const long steps = (long) (minutes * 60.0 / 0.05);
        for (long st = 0; st < steps; ++st)
        {
            in.fx->setParameter (in.fx, ps[(size_t) (rnd() % ps.size())], (float) (rnd() % 1001) / 1000.f);
            if (rnd() % 50 == 0) in.D (effSetProgram, 0, (intptr_t) (rnd() % (uint32_t) in.fx->numPrograms));
            r.block = (int) (16 + rnd() % 1500); r.run (0.05, false);
        }
        CHECK (r.nonFinite == 0 && r.peak < 4.f, "%ld random changes over %.0f min: finite, peak %.2f", steps, minutes, (double) r.peak);
        in.restore(); r.block = 256; r.run (1.0, false);
        CHECK (r.run (0.5) == 0, "after the soak, back to default: clean monitoring");
        in.close();
    }
}

int main (int argc, char** argv)
{
    if (argc < 2) { std::printf ("usage: host_test plugin.so [soak-minutes]\n"); return 2; }
    void* h = dlopen (argv[1], RTLD_NOW);
    if (h == nullptr) { std::printf ("dlopen: %s\n", dlerror()); return 2; }
    main_ = (MainFn) dlsym (h, "VSTPluginMain"); keyOf = (KeyFn) dlsym (h, "DS_ParamKey");
    if (main_ == nullptr || keyOf == nullptr) { std::printf ("missing entry points\n"); return 2; }
    testInterface(); testMonitoring(); testFeatures(); testSessions (argc > 2 ? std::atof (argv[2]) : 1.0);
    std::printf ("\n%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
