// DaFlip DSP tests (run under AddressSanitizer + UBSan by `make test`).
#include "prep/Prep.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <vector>

using namespace sp;
static int checks = 0, fails = 0;
static const bool verbose = std::getenv ("VERBOSE") != nullptr;   // VERBOSE=1: print the measured values of passing checks too
#define CHECK(cond, ...) do { ++checks; if (! (cond)) { ++fails; std::printf ("  FAIL line %d: ", __LINE__); std::printf (__VA_ARGS__); std::printf ("\n"); } \
                              else if (verbose) { std::printf ("  ok:   "); std::printf (__VA_ARGS__); std::printf ("\n"); } } while (0)

static double SR = 44100.0;
struct Buf { std::vector<float> l, r; };
// run 'frames' of input through the engine in blocks; returns the output
static Buf run (Engine& e, const Buf& in, const Settings& s, int blk = 256)
{
    Buf o; o.l.resize (in.l.size()); o.r.resize (in.r.size());
    for (size_t p = 0; p < in.l.size(); p += (size_t) blk)
    {
        const int n = (int) std::min ((size_t) blk, in.l.size() - p);
        e.process (in.l.data() + p, in.r.data() + p, o.l.data() + p, o.r.data() + p, n, s);
    }
    return o;
}
static uint32_t rng = 1;
static float noise() { rng = rng * 1664525u + 1013904223u; return (float) ((int32_t) rng >> 8) / 8388608.f; }
static Buf stereoNoise (double sec, float amp = 0.4f)
{
    Buf b; const size_t n = (size_t) (sec * SR); b.l.resize (n); b.r.resize (n);
    for (size_t i = 0; i < n; ++i) { b.l[i] = amp * noise(); b.r[i] = amp * noise(); }
    return b;
}
// a tone panned with the constant-power law: pan -1 = hard left, 0 = centre, +1 = hard right
static void addTone (Buf& b, double hz, double pan, float amp)
{
    const double th = (pan + 1.0) * M_PI / 4.0, gl = std::cos (th), gr = std::sin (th);
    for (size_t i = 0; i < b.l.size(); ++i) { const double x = amp * std::sin (2 * M_PI * hz * (double) i / SR); b.l[i] += (float) (x * gl); b.r[i] += (float) (x * gr); }
}
static Buf silence (double sec) { Buf b; const size_t n = (size_t) (sec * SR); b.l.assign (n, 0.f); b.r.assign (n, 0.f); return b; }
// amplitude of one frequency in a stretch of a signal (Goertzel), as a sine amplitude
static double tone (const std::vector<float>& x, size_t a, size_t b, double hz)
{
    const double w = 2 * M_PI * hz / SR, c = 2 * std::cos (w); double s1 = 0, s2 = 0;
    for (size_t i = a; i < b; ++i) { const double s0 = x[i] + c * s1 - s2; s2 = s1; s1 = s0; }
    const double pw = s1 * s1 + s2 * s2 - c * s1 * s2;
    return 2.0 * std::sqrt (std::fmax (pw, 0.0)) / (double) (b - a);
}
static double db (double ratio) { return 20.0 * std::log10 (std::fmax (ratio, 1e-12)); }

static void testTransparent()
{
    std::printf ("everything off: bit-exact, no delay, any block size\n");
    for (int blk : { 1, 7, 64, 256, 1000, 1024, 3000 })
    {
        Engine e; e.prepare (SR); Settings s; rng = 7;
        const Buf in = stereoNoise (0.5), o = run (e, in, s, blk);
        int bad = 0; for (size_t i = 0; i < in.l.size(); ++i) if (o.l[i] != in.l[i] || o.r[i] != in.r[i]) ++bad;
        CHECK (bad == 0 && e.latency() == 0, "block %d: %d samples differ, latency %d", blk, bad, e.latency());
    }
}

static void testInputAndPhase()
{
    std::printf ("input modes and phase invert are exact\n");
    rng = 3; const Buf in = stereoNoise (0.2);
    auto exact = [&] (int mode, bool il, bool ir, auto fl, auto fr, const char* what)
    {
        Engine e; e.prepare (SR); Settings s; s.inMode = mode; s.invL = il; s.invR = ir;
        const Buf o = run (e, in, s);
        int bad = 0; for (size_t i = 0; i < in.l.size(); ++i) if (o.l[i] != fl (i) || o.r[i] != fr (i)) ++bad;
        CHECK (bad == 0, "%s: %d samples differ", what, bad);
    };
    exact (1, false, false, [&] (size_t i) { return in.l[i]; }, [&] (size_t i) { return in.l[i]; }, "LEFT to both");
    exact (2, false, false, [&] (size_t i) { return in.r[i]; }, [&] (size_t i) { return in.r[i]; }, "RIGHT to both");
    exact (3, false, false, [&] (size_t i) { return in.r[i]; }, [&] (size_t i) { return in.l[i]; }, "SWAP");
    exact (0, true, false, [&] (size_t i) { return -in.l[i]; }, [&] (size_t i) { return in.r[i]; }, "PHASE L");
    exact (0, false, true, [&] (size_t i) { return in.l[i]; }, [&] (size_t i) { return -in.r[i]; }, "PHASE R");
}

static void testStereo()
{
    std::printf ("mono, width, mid-side encode\n");
    rng = 5; const Buf in = stereoNoise (0.5);
    {
        Engine e; e.prepare (SR); Settings s; s.mono = true; const Buf o = run (e, in, s);
        int bad = 0; double err = 0;
        for (size_t i = (size_t) (0.05 * SR); i < in.l.size(); ++i) { if (o.l[i] != o.r[i]) ++bad; err = std::fmax (err, std::fabs (o.l[i] - 0.5 * (in.l[i] + in.r[i]))); }
        CHECK (bad == 0 && err < 1e-6, "MONO: L == R == (L+R)/2 (%d differ, err %g)", bad, err);
    }
    {
        Engine e; e.prepare (SR); Settings s; s.width = 2.f; const Buf o = run (e, in, s);
        double err = 0;
        for (size_t i = (size_t) (0.05 * SR); i < in.l.size(); ++i)
        {
            const double m = 0.5 * (in.l[i] + in.r[i]), sd = 0.5 * (in.l[i] - in.r[i]);
            err = std::fmax (err, std::fabs (o.l[i] - (m + 2 * sd))) + 0 * std::fabs (o.r[i] - (m - 2 * sd));
        }
        CHECK (err < 1e-6, "WIDTH 200 %%: the side doubles (err %g)", err);
    }
    {
        Engine e; e.prepare (SR); Settings s; s.msEncode = true; const Buf o = run (e, in, s);
        double err = 0; for (size_t i = 0; i < in.l.size(); ++i) err = std::fmax (err, std::fabs (o.l[i] - 0.5 * (in.l[i] + in.r[i])) + std::fabs (o.r[i] - 0.5 * (in.l[i] - in.r[i])));
        CHECK (err < 1e-6, "MID-SIDE: L = mid, R = side (err %g)", err);
    }
}

static void testBassMono()
{
    std::printf ("bass mono: low side removed, high side and the centre untouched\n");
    auto sideTone = [] (double hz) { Buf b = silence (1.0); for (size_t i = 0; i < b.l.size(); ++i) { const float x = (float) (0.5 * std::sin (2 * M_PI * hz * i / SR)); b.l[i] = x; b.r[i] = -x; } return b; };
    Settings s; s.bassMono = true; s.bassHz = 120.f;
    { Engine e; e.prepare (SR); const Buf in = sideTone (50); const Buf o = run (e, in, s);
      const double a = tone (o.l, (size_t) (0.5 * SR), in.l.size(), 50);
      CHECK (db (a / 0.5) < -20, "50 Hz on the sides: %.1f dB", db (a / 0.5)); }
    { Engine e; e.prepare (SR); const Buf in = sideTone (1000); const Buf o = run (e, in, s);
      const double a = tone (o.l, (size_t) (0.5 * SR), in.l.size(), 1000);
      CHECK (std::fabs (db (a / 0.5)) < 0.5, "1 kHz on the sides: %.2f dB", db (a / 0.5)); }
    { Engine e; e.prepare (SR); Buf in = silence (1.0); addTone (in, 50, 0.0, 0.5f); const Buf o = run (e, in, s);
      double err = 0; for (size_t i = 0; i < in.l.size(); ++i) err = std::fmax (err, std::fabs (o.l[i] - in.l[i]));
      CHECK (err < 1e-5, "50 Hz in the centre: untouched (err %g)", err); }
}

static void testDcGainPanMute()
{
    std::printf ("DC removal, gain, balance, mute, listen modes\n");
    { Engine e; e.prepare (SR); Settings s; s.dc = true; Buf in = silence (2.0); for (auto& x : in.l) x = 0.5f; for (auto& x : in.r) x = -0.3f;
      const Buf o = run (e, in, s); CHECK (std::fabs (o.l.back()) < 1e-3 && std::fabs (o.r.back()) < 1e-3, "DC offset removed (%g, %g)", (double) o.l.back(), (double) o.r.back()); }
    { Engine e; e.prepare (SR); Settings s; s.gainDb = 6.0206f; rng = 9; const Buf in = stereoNoise (0.3); const Buf o = run (e, in, s);
      double err = 0; for (size_t i = (size_t) (0.05 * SR); i < in.l.size(); ++i) err = std::fmax (err, std::fabs (o.l[i] - 2.0 * in.l[i]));
      CHECK (err < 1e-5, "GAIN +6 dB = x2 (err %g)", err); }
    { Engine e; e.prepare (SR); Settings s; s.pan = -1.f; rng = 9; const Buf in = stereoNoise (0.3); const Buf o = run (e, in, s);
      double rmax = 0, lerr = 0; for (size_t i = (size_t) (0.05 * SR); i < in.l.size(); ++i) { rmax = std::fmax (rmax, std::fabs (o.r[i])); lerr = std::fmax (lerr, std::fabs (o.l[i] - in.l[i])); }
      CHECK (rmax == 0 && lerr == 0, "PAN full left: right silent, left untouched (%g, %g)", rmax, lerr); }
    { Engine e; e.prepare (SR); Settings s; s.mute = true; rng = 9; const Buf in = stereoNoise (0.3); const Buf o = run (e, in, s);
      double mx = 0; for (size_t i = (size_t) (0.01 * SR); i < in.l.size(); ++i) mx = std::fmax (mx, std::fabs (o.l[i]) + std::fabs (o.r[i]));
      CHECK (mx == 0, "MUTE: silence after a 5 ms fade (%g)", mx); }
    { Engine e; e.prepare (SR); Settings s; s.listen = 2; Buf in = silence (0.5); addTone (in, 440, 0.0, 0.5f);
      const Buf o = run (e, in, s); double mx = 0; for (float x : o.l) mx = std::fmax (mx, std::fabs (x));
      CHECK (mx < 1e-6, "LISTEN SIDE: a centred tone vanishes (%g)", mx); }
    { Engine e; e.prepare (SR); Settings s; s.listen = 3; s.bassHz = 120; Buf in = silence (1.0); addTone (in, 60, 0.0, 0.3f); addTone (in, 2000, 0.0, 0.3f);
      const Buf o = run (e, in, s); const double lo = tone (o.l, (size_t) (0.5 * SR), o.l.size(), 60), hi = tone (o.l, (size_t) (0.5 * SR), o.l.size(), 2000);
      CHECK (lo > 0.15 && db (hi / 0.21) < -40, "LISTEN BASS: 60 Hz stays (%.2f), 2 kHz gone (%.0f dB)", lo, db (hi / 0.21)); }
}

static void testIsolator()
{
    std::printf ("pan isolator: perfect reconstruction, separation by position and by frequency, KEEP and REMOVE\n");
    {   // everything kept: the input comes back, delayed by the latency
        Engine e; e.prepare (SR); Settings s; s.isoMode = 1; s.isoWidth = 2.f; s.isoSoft = 0; s.isoSmooth = 0;
        rng = 11; const Buf in = stereoNoise (1.5); const Buf o = run (e, in, s);
        const int L = e.latency(); double err = 0;
        for (size_t i = (size_t) (0.6 * SR); i < in.l.size(); ++i) err = std::fmax (err, std::fabs (o.l[i] - in.l[i - (size_t) L]) + std::fabs (o.r[i] - in.r[i - (size_t) L]));
        CHECK (L == 2048 && err < 2e-5, "keep everything = the input, %d samples later (max error %g)", L, err);
    }
    // three tones at three positions: 440 Hz hard left, 660 Hz centre, 990 Hz half right
    Buf mix = silence (3.0); addTone (mix, 440, -1.0, 0.3f); addTone (mix, 660, 0.0, 0.3f); addTone (mix, 990, 0.5, 0.3f);
    auto measure = [&] (const Settings& s, double& a440, double& a660, double& a990)
    {
        Engine e; e.prepare (SR); const Buf o = run (e, mix, s);
        const size_t a = (size_t) (1.5 * SR), b = o.l.size();
        auto both = [&] (double hz) { return std::sqrt (tone (o.l, a, b, hz) * tone (o.l, a, b, hz) + tone (o.r, a, b, hz) * tone (o.r, a, b, hz)); };
        a440 = both (440); a660 = both (660); a990 = both (990);
    };
    double x, y, z;
    { Settings s; s.isoMode = 1; s.isoPos = -1.f; s.isoWidth = 0.2f; measure (s, x, y, z);
      CHECK (db (x / 0.3) > -1 && db (y / 0.3) < -30 && db (z / 0.3) < -30, "KEEP hard left: 440 %.1f dB, 660 %.1f dB, 990 %.1f dB", db (x / 0.3), db (y / 0.3), db (z / 0.3)); }
    { Settings s; s.isoMode = 1; s.isoPos = 0.5f; s.isoWidth = 0.15f; measure (s, x, y, z);
      CHECK (db (z / 0.3) > -1 && db (x / 0.3) < -30 && db (y / 0.3) < -30, "KEEP R 50: 990 %.1f dB, 440 %.1f dB, 660 %.1f dB", db (z / 0.3), db (x / 0.3), db (y / 0.3)); }
    { Settings s; s.isoMode = 2; s.isoPos = 0.f; s.isoWidth = 0.1f; measure (s, x, y, z);
      CHECK (db (y / 0.3) < -30 && db (x / 0.3) > -1 && db (z / 0.3) > -1, "REMOVE centre: 660 %.1f dB, 440 %.1f dB, 990 %.1f dB", db (y / 0.3), db (x / 0.3), db (z / 0.3)); }
    { Settings s; s.isoMode = 1; s.isoPos = 0.f; s.isoWidth = 2.f; s.isoLo = 500; s.isoHi = 800; measure (s, x, y, z);
      CHECK (db (y / 0.3) > -1 && db (x / 0.3) < -30 && db (z / 0.3) < -30, "KEEP 500-800 Hz anywhere: 660 %.1f dB, 440 %.1f, 990 %.1f", db (y / 0.3), db (x / 0.3), db (z / 0.3)); }
    {   // what survives keeps its own stereo placement
        Settings s; s.isoMode = 1; s.isoPos = 0.5f; s.isoWidth = 0.15f;
        Engine e; e.prepare (SR); const Buf o = run (e, mix, s);
        const size_t a = (size_t) (1.5 * SR), b = o.l.size();
        const double ratio = tone (o.r, a, b, 990) / std::fmax (tone (o.l, a, b, 990), 1e-9), want = std::tan (1.5 * M_PI / 4.0);
        CHECK (std::fabs (ratio / want - 1.0) < 0.05, "the kept part stays half right (R/L %.2f, was %.2f)", ratio, want);
    }
    {   // on and off: fades in once valid, back to bit-exact when off
        Engine e; e.prepare (SR); Settings s; s.isoMode = 1; s.isoPos = -1.f;
        rng = 2; Buf in = stereoNoise (1.0); run (e, in, s);
        CHECK (e.latency() == 2048 && e.isolating(), "on: isolating, latency %d", e.latency());
        s.isoMode = 0; run (e, in, s);
        const Buf o = run (e, in, s);
        int bad = 0; for (size_t i = 0; i < in.l.size(); ++i) if (o.l[i] != in.l[i] || o.r[i] != in.r[i]) ++bad;
        CHECK (bad == 0 && e.latency() == 0, "off: bit-exact again, no latency (%d differ)", bad);
    }
    for (double rate : { 48000.0, 96000.0 })
    {
        const double keep = SR; SR = rate;
        Buf m2 = silence (3.0); addTone (m2, 440, -1.0, 0.3f); addTone (m2, 660, 0.0, 0.3f);
        Engine e; e.prepare (SR); Settings s; s.isoMode = 1; s.isoPos = -1.f; s.isoWidth = 0.2f;
        const Buf o = run (e, m2, s); const size_t a = (size_t) (1.5 * SR);
        const double a440 = tone (o.l, a, o.l.size(), 440), a660 = std::fmax (tone (o.l, a, o.l.size(), 660), tone (o.r, a, o.r.size(), 660));
        CHECK (db (a440 / 0.3) > -1 && db (a660 / 0.3) < -30 && e.latency() == (rate > 50000 ? 4096 : 2048),
               "%.0f kHz: hard left kept (%.1f dB), centre gone (%.1f dB), latency %d", rate / 1000, db (a440 / 0.3), db (a660 / 0.3), e.latency());
        SR = keep;
    }
}

static void testMeters()
{
    std::printf ("correlation meter\n");
    auto corr = [] (int kind) { Engine e; e.prepare (SR); Settings s; rng = 4; Buf in = stereoNoise (1.0);
        for (size_t i = 0; i < in.l.size(); ++i) { if (kind == 0) in.r[i] = in.l[i]; else if (kind == 1) in.r[i] = -in.l[i]; }
        run (e, in, s); return e.correlation(); };
    const float same = corr (0), inv = corr (1), indep = corr (2);
    CHECK (same > 0.99f && inv < -0.99f && std::fabs (indep) < 0.1f, "identical %+.2f, inverted %+.2f, independent %+.2f", (double) same, (double) inv, (double) indep);
}

static void testSmoothAndFinite()
{
    std::printf ("no zipper noise on a gain jump; random settings stay finite\n");
    {
        Engine e; e.prepare (SR); Settings s; Buf in = silence (0.5); for (auto& x : in.l) x = 0.5f; for (auto& x : in.r) x = 0.5f;
        run (e, in, s); s.gainDb = 12.f; const Buf o = run (e, in, s);
        float step = 0; for (size_t i = 1; i < o.l.size(); ++i) step = std::fmax (step, std::fabs (o.l[i] - o.l[i - 1]));
        CHECK (step < 0.01f, "gain 0 -> +12 dB glides over 20 ms (largest step %g)", (double) step);
    }
    bool finite = true; float peak = 0; Engine e; e.prepare (SR); rng = 77;
    for (int k = 0; k < 400; ++k)
    {
        Settings s; auto r = [] { rng = rng * 1103515245u + 12345u; return (float) ((rng >> 8) & 0xFFFF) / 65535.f; };
        s.inMode = (int) (r() * 3.99f); s.invL = r() > 0.7f; s.invR = r() > 0.7f; s.dc = r() > 0.5f; s.mono = r() > 0.8f; s.width = r() * 2;
        s.bassMono = r() > 0.5f; s.bassHz = 40 + r() * 360; s.msEncode = r() > 0.8f; s.gainDb = -20 + r() * 26; s.pan = r() * 2 - 1;
        s.mute = r() > 0.9f; s.listen = (int) (r() * 3.99f); s.isoMode = (int) (r() * 2.99f); s.isoPos = r() * 2 - 1; s.isoWidth = 0.02f + r();
        s.isoSoft = r() * 0.5f; s.isoLo = 20 + r() * 2000; s.isoHi = 200 + r() * 19800; s.isoSmooth = r(); s.bypass = r() > 0.95f;
        rng ^= (uint32_t) k; const Buf in = stereoNoise (0.03, 0.8f); const Buf o = run (e, in, s, 1 + (int) (r() * 1023));
        for (size_t i = 0; i < o.l.size(); ++i) { if (! std::isfinite (o.l[i]) || ! std::isfinite (o.r[i])) finite = false; peak = std::fmax (peak, std::fmax (std::fabs (o.l[i]), std::fabs (o.r[i]))); }
    }
    CHECK (finite && peak < 8.f, "400 random settings and block sizes: finite, peak %.2f", (double) peak);
}

int main()
{
    testTransparent(); testInputAndPhase(); testStereo(); testBassMono(); testDcGainPanMute(); testIsolator(); testMeters(); testSmoothAndFinite();
    std::printf ("\n%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
