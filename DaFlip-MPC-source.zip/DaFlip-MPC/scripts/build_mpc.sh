#!/usr/bin/env bash
# Build DaFlip for the MPC on your own computer (no GitHub), and optionally install it over SSH in the same step.
#
#   ./scripts/build_mpc.sh                    -> dist/DaFlip-<version>-mpc-armv7.zip (+ dist/setup.sh)
#   ./scripts/build_mpc.sh 192.168.1.50       -> builds, copies it to the MPC over SSH (user root) and runs the installer
#   YES=1 ./scripts/build_mpc.sh 192.168.1.50 -> same, without the on-device "Continue? [y/N]" question
#
# Works on: Ubuntu / Debian / Linux Mint, Windows 10/11 inside WSL (Ubuntu), and any Mac / Windows / Linux with Docker.
# What it needs, in order of preference:
#   1. the ARM cross-compiler (arm-linux-gnueabihf-g++); on Ubuntu/Debian/WSL it offers to install it with apt (needs sudo)
#   2. otherwise Docker (Docker Desktop on Mac/Windows): builds inside an ARM Ubuntu 22.04 container
# The finished .so is checked against what a Gen1 MPC can load (32-bit ARM, hard-float, libc/libm only, glibc <= 2.34)
# before anything is packaged.
set -euo pipefail
cd "$(dirname "$0")/.."
VERSION=$(sed -n 's/^VERSION=\([0-9.]*\).*/\1/p' scripts/package.sh)

have() { command -v "$1" >/dev/null 2>&1; }

# USE_DOCKER=1 forces the container build (also the fix if a very new Linux makes a binary that needs a newer glibc)
if [ "${USE_DOCKER:-0}" != 1 ] && ! have arm-linux-gnueabihf-g++ && ! have docker; then
    if have apt-get; then
        echo "The ARM cross-compiler isn't installed. Installing it now (asks for your password):"
        sudo apt-get update -qq
        sudo apt-get install -y -qq g++-arm-linux-gnueabihf binutils-arm-linux-gnueabihf binutils make zip file
    else
        echo "Need either the ARM cross-compiler or Docker."
        echo "  Windows: install WSL (in PowerShell: wsl --install), open Ubuntu, and run this script there."
        echo "  Mac:     install Docker Desktop, start it, and run this script again."
        exit 1
    fi
fi

rm -rf build/arm
if [ "${USE_DOCKER:-0}" != 1 ] && have arm-linux-gnueabihf-g++; then
    for t in make zip readelf sha256sum; do have "$t" || { echo "missing '$t' (Ubuntu: sudo apt-get install make zip binutils coreutils)"; exit 1; }; done
    export READELF=arm-linux-gnueabihf-readelf; have "$READELF" || export READELF=readelf
    if have g++ && have gcc; then                    # optional offline tests on this computer
        echo "== tests (x86, optional) =="
        if make -s test >/tmp/daflip-test.log 2>&1; then grep -E "checks" /tmp/daflip-test.log
        else echo "tests didn't run cleanly here (see /tmp/daflip-test.log); carrying on with the MPC build"; fi
    fi
    echo "== building for the MPC (32-bit ARM) with the cross-compiler =="
    ./scripts/package.sh
else
    have docker || { echo "Docker not found"; exit 1; }
    echo "== building for the MPC (32-bit ARM) inside an Ubuntu 22.04 container (first run downloads ~300 MB) =="
    docker run --rm -v "$PWD":/src -w /src ubuntu:22.04 bash -c '
        set -e
        export DEBIAN_FRONTEND=noninteractive
        apt-get update -qq >/dev/null
        apt-get install -y -qq g++-arm-linux-gnueabihf binutils-arm-linux-gnueabihf make zip file >/dev/null
        READELF=arm-linux-gnueabihf-readelf ./scripts/package.sh
        chown -R '"$(id -u):$(id -g)"' build dist'
fi

ZIP="dist/DaFlip-$VERSION-mpc-armv7.zip"
[ -f "$ZIP" ] || { echo "packaging failed"; exit 1; }
echo
echo "Built: $ZIP"
echo "       dist/setup.sh   (for installing from a phone with Terminus: upload both to /tmp, then: sh /tmp/setup.sh)"

if [ $# -ge 1 ]; then
    have ssh || { echo "no ssh client on this computer"; exit 1; }
    echo
    echo "== installing on the MPC at $1 =="
    ./scripts/deploy.sh "$1" "${2:-root}"
else
    echo
    echo "Install over SSH from this computer:  ./scripts/build_mpc.sh <mpc-ip>   (or ./scripts/deploy.sh <mpc-ip>)"
fi
