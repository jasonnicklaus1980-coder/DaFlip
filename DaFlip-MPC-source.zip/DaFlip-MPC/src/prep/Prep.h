// DaFlip DSP: a stereo utility for sampling, plus a pan-position isolator.
//
// Signal chain (everything off = bit-exact pass-through, no latency):
//   input mode (stereo / left / right / swap) -> phase invert L / R -> DC removal
//   -> PAN ISOLATOR (STFT, adds latency only while it is on) -> width / mono (mid-side) -> bass mono (the side through a
//   4th-order high-pass: centred bass and kick are never touched) -> M/S encode -> gain -> balance -> mute -> listen
//   (mid = mono check, side, bass) ; meters (L / R level, phase correlation) read the stereo signal before LISTEN.
//
// The pan isolator splits the sound into short overlapping frames (sqrt-Hann, 75 % overlap), takes one complex FFT of
// L + iR per frame, recovers both channel spectra from it, and for every frequency bin estimates where it sits between left
// and right (angle of |R| vs |L|: -1 = hard left, 0 = centre, +1 = hard right). Bins near the chosen position (and inside
// the chosen frequency range) are kept (KEEP) or removed (REMOVE). The same real gain is applied to both channels, so what
// survives keeps its own stereo placement. The gains are smoothed over time against the "watery" sound of fast masks.
//
// Audio-thread only (prepare on the host thread). No allocation: fixed buffers for FFTs up to 8192. No libstdc++.
#pragma once
#include <cmath>
#include <cstdint>
#include <cstring>

namespace sp
{
inline float clampf (float x, float lo, float hi) { return x < lo ? lo : (x > hi ? hi : x); }
// Values that decay towards zero (filter memories, smoothed gains, meter averages) would otherwise pass through denormal
// numbers, which many CPUs (the MPC's ARM included) process very slowly. Snap them to exact zero when inaudibly small.
inline float undenorm (float x) { return (x > -1e-15f && x < 1e-15f) ? 0.f : x; }
inline double clampd (double x, double lo, double hi) { return x < lo ? lo : (x > hi ? hi : x); }

struct Settings
{
    int inMode = 0;                 // 0 stereo, 1 left (to both), 2 right (to both), 3 swap
    bool invL = false, invR = false;
    bool dc = false;
    bool mono = false; float width = 1.f;           // 0 = mono ... 1 = as is ... 2 = twice as wide
    bool bassMono = false; float bassHz = 120.f;
    bool msEncode = false;                          // out L = mid, out R = side
    float gainDb = 0.f; float pan = 0.f;            // pan = balance, -1 .. +1
    bool mute = false;
    int listen = 0;                                 // 0 normal, 1 mid (mono check), 2 side, 3 bass
    // pan isolator
    int isoMode = 0;                                // 0 off, 1 keep, 2 remove
    float isoPos = 0.f;                             // -1 hard left .. 0 centre .. +1 hard right
    float isoWidth = 0.2f;                          // half-width of the kept window, in pan units (0.02 .. 1)
    float isoSoft = 0.1f;                           // soft edge beyond the window, pan units
    float isoLo = 20.f, isoHi = 20000.f;            // frequency range it acts on
    float isoSmooth = 0.3f;                         // 0 .. 1: time smoothing of the mask (0 = none, 1 = ~200 ms)
    bool bypass = false;
};

// ---------------------------------------------------------------------------------------------- small pieces
struct Ramp                                         // linear glide to an exact target (no zipper noise, exact at rest)
{
    float cur = 0, tgt = 0, step = 0;
    void set (float v) { cur = tgt = v; step = 0; }
    void to (float v, int frames) { if (v != tgt) { tgt = v; step = (tgt - cur) / (float) (frames > 0 ? frames : 1); } }
    inline float next() { if (cur != tgt) { cur += step; if ((step > 0 && cur >= tgt) || (step < 0 && cur <= tgt) || step == 0) cur = tgt; } return cur; }
    bool still() const { return cur == tgt; }
};
struct Biquad                                       // transposed direct form II
{
    float b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0, z1 = 0, z2 = 0;
    void highpass (double fs, double f0)
    {
        const double w = 2.0 * M_PI * clampd (f0, 10.0, fs * 0.45) / fs, c = std::cos (w), al = std::sin (w) / (2.0 * 0.70710678);
        const double a0 = 1.0 + al;
        b0 = (float) ((1.0 + c) * 0.5 / a0); b1 = (float) (-(1.0 + c) / a0); b2 = b0;
        a1 = (float) (-2.0 * c / a0); a2 = (float) ((1.0 - al) / a0);
    }
    void lowpass (double fs, double f0)             // RBJ, Q = 1/sqrt(2): two in series = Linkwitz-Riley 4th order
    {
        const double w = 2.0 * M_PI * clampd (f0, 10.0, fs * 0.45) / fs, c = std::cos (w), al = std::sin (w) / (2.0 * 0.70710678);
        const double a0 = 1.0 + al;
        b0 = (float) ((1.0 - c) * 0.5 / a0); b1 = (float) ((1.0 - c) / a0); b2 = b0;
        a1 = (float) (-2.0 * c / a0); a2 = (float) ((1.0 - al) / a0);
    }
    inline float run (float x) { const float y = b0 * x + z1; z1 = undenorm (b1 * x - a1 * y + z2); z2 = undenorm (b2 * x - a2 * y); return y; }
    void clear() { z1 = z2 = 0; }
};
struct LR4
{
    Biquad a, b;
    void set (double fs, double f, bool high = false) { if (high) { a.highpass (fs, f); b.highpass (fs, f); } else { a.lowpass (fs, f); b.lowpass (fs, f); } }
    inline float run (float x) { return b.run (a.run (x)); }
    void clear() { a.clear(); b.clear(); }
};

// ---------------------------------------------------------------------------------------------- FFT (radix 2, in place)
constexpr int kMaxN = 8192;
struct FFT
{
    int n = 0;
    float cosT[kMaxN / 2], sinT[kMaxN / 2];
    uint16_t rev[kMaxN];
    void init (int N)
    {
        n = N; int bits = 0; while ((1 << bits) < N) ++bits;
        for (int i = 0; i < N; ++i) { int r = 0; for (int b = 0; b < bits; ++b) if (i & (1 << b)) r |= 1 << (bits - 1 - b); rev[i] = (uint16_t) r; }
        for (int i = 0; i < N / 2; ++i) { cosT[i] = (float) std::cos (2.0 * M_PI * i / N); sinT[i] = (float) std::sin (2.0 * M_PI * i / N); }
    }
    void run (float* re, float* im, bool inverse) const
    {
        for (int i = 0; i < n; ++i) { const int j = rev[i]; if (j > i) { float t = re[i]; re[i] = re[j]; re[j] = t; t = im[i]; im[i] = im[j]; im[j] = t; } }
        for (int len = 2; len <= n; len <<= 1)
        {
            const int half = len >> 1, step = n / len;
            for (int i = 0; i < n; i += len)
                for (int j = 0; j < half; ++j)
                {
                    const float wr = cosT[j * step], wi = inverse ? sinT[j * step] : -sinT[j * step];
                    const int a = i + j, b = a + half;
                    const float xr = re[b] * wr - im[b] * wi, xi = re[b] * wi + im[b] * wr;
                    re[b] = re[a] - xr; im[b] = im[a] - xi; re[a] += xr; im[a] += xi;
                }
        }
    }
};

// ---------------------------------------------------------------------------------------------- the pan isolator
class Isolator
{
public:
    void prepare (double sr)
    {
        sr_ = sr;
        N_ = sr <= 50000.0 ? 2048 : (sr <= 100000.0 ? 4096 : 8192);       // ~46 ms of analysis at any rate
        hop_ = N_ / 4;
        fft_.init (N_);
        for (int k = 0; k < N_; ++k) win_[k] = (float) std::sqrt (0.5 * (1.0 - std::cos (2.0 * M_PI * k / N_)));
        reset();
    }
    void reset()
    {
        std::memset (inL_, 0, sizeof inL_); std::memset (inR_, 0, sizeof inR_);
        std::memset (olaL_, 0, sizeof olaL_); std::memset (olaR_, 0, sizeof olaR_);
        std::memset (rdyL_, 0, sizeof rdyL_); std::memset (rdyR_, 0, sizeof rdyR_);
        fill_ = 0; first_ = true; produced_ = 0;
    }
    int latency() const { return N_; }
    int64_t produced() const { return produced_; }          // samples output since reset (valid once >= latency)
    // one stereo sample in, one out (delayed by latency())
    inline void process (float& l, float& r, const Settings& s)
    {
        const float yl = rdyL_[fill_], yr = rdyR_[fill_];
        inL_[N_ - hop_ + fill_] = l; inR_[N_ - hop_ + fill_] = r;
        if (++fill_ == hop_) { frame (s); fill_ = 0; }
        l = yl; r = yr; ++produced_;
    }
private:
    void frame (const Settings& s)
    {
        const int N = N_, h = hop_;
        for (int k = 0; k < N; ++k) { re_[k] = inL_[k] * win_[k]; im_[k] = inR_[k] * win_[k]; }
        fft_.run (re_, im_, false);
        // the mask, per bin
        const float pos = clampf (s.isoPos, -1.f, 1.f), wd = clampf (s.isoWidth, 0.005f, 2.f), soft = clampf (s.isoSoft, 0.f, 1.f);
        const double binHz = sr_ / N;
        // the range at its ends means "no limit": 20 Hz includes everything below, 20 kHz everything above
        const int kLo = s.isoLo <= 20.5f ? 0 : (int) std::ceil (clampd (s.isoLo, 0.0, sr_ / 2) / binHz);
        const int kHi = s.isoHi >= 19999.f ? N / 2 : (int) std::floor (clampd (s.isoHi, 0.0, sr_ / 2) / binHz);
        const float tau = clampf (s.isoSmooth, 0.f, 1.f) * 0.2f;
        const float keep = tau > 0.f ? std::exp (-(float) h / (float) sr_ / tau) : 0.f;      // how much of the old gain stays
        const bool removeMode = s.isoMode == 2;
        for (int k = 0; k <= N / 2; ++k)
        {
            const int kn = (N - k) & (N - 1);
            const float zr = re_[k], zi = im_[k], nr = re_[kn], ni = im_[kn];
            const float lr = 0.5f * (zr + nr), li = 0.5f * (zi - ni);              // left spectrum
            const float rr = 0.5f * (zi + ni), ri = -0.5f * (zr - nr);             // right spectrum
            const float al = std::sqrt (lr * lr + li * li), ar = std::sqrt (rr * rr + ri * ri);
            const float p = (al + ar) > 1e-12f ? std::atan2 (ar, al) * 1.2732395f - 1.f : 0.f;   // atan2 * 4/pi - 1
            float m = 0.f;
            const float d = std::fabs (p - pos);
            if (d <= wd) m = 1.f;
            else if (soft > 0.f && d < wd + soft) m = 0.5f * (1.f + std::cos (3.14159265f * (d - wd) / soft));
            const bool inBand = k >= kLo && k <= kHi;
            float g = removeMode ? (inBand ? 1.f - m : 1.f) : (inBand ? m : 0.f);
            if (first_) mask_[k] = g; else mask_[k] = g + (mask_[k] - g) * keep;
            if (mask_[k] < 1e-6f) mask_[k] = 0.f; else if (mask_[k] > 1.f - 1e-6f) mask_[k] = 1.f;   // settle exactly (no denormals)
            g = mask_[k];
            re_[k] *= g; im_[k] *= g;
            if (k != 0 && k != N / 2) { re_[kn] *= g; im_[kn] *= g; }
        }
        first_ = false;
        fft_.run (re_, im_, true);
        const float scale = 0.5f / (float) N;                              // 1/N for the inverse FFT, 1/2 for the overlap
        for (int k = 0; k < N; ++k) { olaL_[k] += re_[k] * win_[k] * scale; olaR_[k] += im_[k] * win_[k] * scale; }
        std::memcpy (rdyL_, olaL_, sizeof (float) * (size_t) h); std::memcpy (rdyR_, olaR_, sizeof (float) * (size_t) h);
        std::memmove (olaL_, olaL_ + h, sizeof (float) * (size_t) (N - h)); std::memmove (olaR_, olaR_ + h, sizeof (float) * (size_t) (N - h));
        std::memset (olaL_ + N - h, 0, sizeof (float) * (size_t) h); std::memset (olaR_ + N - h, 0, sizeof (float) * (size_t) h);
        std::memmove (inL_, inL_ + h, sizeof (float) * (size_t) (N - h)); std::memmove (inR_, inR_ + h, sizeof (float) * (size_t) (N - h));
    }
    double sr_ = 44100; int N_ = 2048, hop_ = 512, fill_ = 0; bool first_ = true; int64_t produced_ = 0;
    FFT fft_;
    float win_[kMaxN], inL_[kMaxN], inR_[kMaxN], olaL_[kMaxN], olaR_[kMaxN], rdyL_[kMaxN / 4], rdyR_[kMaxN / 4];
    float re_[kMaxN], im_[kMaxN], mask_[kMaxN / 2 + 1];
};

// ---------------------------------------------------------------------------------------------- the whole chain
class Engine
{
public:
    void prepare (double sr)
    {
        sr_ = clampd (sr, 8000.0, 192000.0);
        iso_.prepare (sr_);
        reset();
    }
    void reset()
    {
        dcxL_ = dcxR_ = dcyL_ = dcyR_ = 0; sideHP_.clear(); bassLP_.clear(); lastBassHz_ = -1;
        gain_.set (1.f); width_.set (1.f); panL_.set (1.f); panR_.set (1.f); mute_.set (1.f);
        isoOn_ = false; isoMix_ = 0; iso_.reset();
        sLL_ = sRR_ = sLR_ = 0; pkL_ = pkR_ = 0; msL_ = msR_ = 0;
    }
    int latency() const { return isoOn_ ? iso_.latency() : 0; }
    bool isolating() const { return isoOn_ && isoMix_ > 0.f; }
    float correlation() const { return (sLL_ > 1e-10f && sRR_ > 1e-10f) ? clampf (sLR_ / std::sqrt (sLL_ * sRR_), -1.f, 1.f) : 1.f; }
    bool hasSignal() const { return sLL_ > 1e-9f || sRR_ > 1e-9f; }
    float peakL() const { return pkL_; }
    float peakR() const { return pkR_; }
    float rmsDbL() const { return msL_ > 1e-12f ? 10.f * std::log10 (msL_) : -120.f; }
    float rmsDbR() const { return msR_ > 1e-12f ? 10.f * std::log10 (msR_) : -120.f; }

    void process (const float* inL, const float* inR, float* outL, float* outR, int n, const Settings& s)
    {
        while (n > 1024) { process (inL, inR, outL, outR, 1024, s); inL += 1024; inR += 1024; outL += 1024; outR += 1024; n -= 1024; }
        if (s.bypass)
        {
            for (int i = 0; i < n; ++i) { outL[i] = inL[i]; outR[i] = inR[i]; }
            meters (outL, outR, n);
            return;
        }
        const int ramp = (int) (0.02 * sr_);
        // targets (smoothed, exact at rest)
        gain_.to (s.gainDb <= -60.f ? 0.f : (s.gainDb == 0.f ? 1.f : std::pow (10.f, s.gainDb / 20.f)), ramp);
        width_.to (s.mono ? 0.f : clampf (s.width, 0.f, 2.f), ramp);
        const float pan = clampf (s.pan, -1.f, 1.f);
        panL_.to (pan > 0.f ? 1.f - pan : 1.f, ramp); panR_.to (pan < 0.f ? 1.f + pan : 1.f, ramp);
        mute_.to (s.mute ? 0.f : 1.f, (int) (0.005 * sr_));
        const float bassHz = clampf (s.bassHz, 20.f, 1000.f);
        if (bassHz != lastBassHz_) { sideHP_.set (sr_, bassHz, true); bassLP_.set (sr_, bassHz); lastBassHz_ = bassHz; }
        const float dcA = (float) (1.0 - 2.0 * M_PI * 5.0 / sr_);
        // the isolator: start it when asked; fade it in once its first output is valid; stop it once faded out
        const bool wantIso = s.isoMode != 0;
        if (wantIso && ! isoOn_) { iso_.reset(); isoOn_ = true; isoMix_ = 0; }
        const float isoStep = (float) (1.0 / (0.01 * sr_));

        for (int i = 0; i < n; ++i)
        {
            float l = inL[i], r = inR[i];
            switch (s.inMode) { case 1: r = l; break; case 2: l = r; break; case 3: { const float t = l; l = r; r = t; break; } default: break; }
            if (s.invL) l = -l;
            if (s.invR) r = -r;
            if (s.dc)
            {
                const float yl = l - dcxL_ + dcA * dcyL_, yr = r - dcxR_ + dcA * dcyR_;
                dcxL_ = l; dcxR_ = r; dcyL_ = undenorm (yl); dcyR_ = undenorm (yr); l = yl; r = yr;
            }
            if (isoOn_)
            {
                float wl = l, wr = r;
                iso_.process (wl, wr, s);
                const float tgt = (wantIso && iso_.produced() > iso_.latency()) ? 1.f : 0.f;
                if (isoMix_ < tgt) isoMix_ = std::fmin (isoMix_ + isoStep, tgt); else if (isoMix_ > tgt) isoMix_ = std::fmax (isoMix_ - isoStep, tgt);
                if (isoMix_ >= 1.f) { l = wl; r = wr; }
                else if (isoMix_ > 0.f) { l = l * (1.f - isoMix_) + wl * isoMix_; r = r * (1.f - isoMix_) + wr * isoMix_; }
                if (! wantIso && isoMix_ <= 0.f) isoOn_ = false;
            }
            // mid / side: width, mono, bass mono
            const float w = width_.next();
            if (w != 1.f || ! width_.still() || s.bassMono)
            {
                const float m = (l + r) * 0.5f;
                float sd = (l - r) * 0.5f * w;
                if (s.bassMono) sd = sideHP_.run (sd);                    // the side's low end goes: bass in mono
                l = m + sd; r = m - sd;
            }
            if (s.msEncode) { const float m = (l + r) * 0.5f, sd = (l - r) * 0.5f; l = m; r = sd; }
            const float g = gain_.next();
            if (g != 1.f) { l *= g; r *= g; }
            const float pl = panL_.next(), pr = panR_.next();
            if (pl != 1.f) l *= pl;
            if (pr != 1.f) r *= pr;
            const float mu = mute_.next();
            if (mu != 1.f) { l *= mu; r *= mu; }
            mL_[i] = l; mR_[i] = r;                                       // what the meters read (before LISTEN)
            switch (s.listen)
            {
                case 1: { const float m = (l + r) * 0.5f; l = r = m; break; }
                case 2: { const float sd = (l - r) * 0.5f; l = r = sd; break; }
                case 3: { const float b = bassLP_.run ((l + r) * 0.5f); l = r = b; break; }
                default: break;
            }
            outL[i] = l; outR[i] = r;
        }
        meters (mL_, mR_, n);
    }

private:
    void meters (const float* l, const float* r, int n)
    {
        const float a = (float) (1.0 - std::exp (-1.0 / (0.3 * sr_)));     // 300 ms averaging
        const float dec = (float) std::exp (-(double) n / (0.4 * sr_));
        float pl = pkL_ * dec, pr = pkR_ * dec;
        for (int i = 0; i < n; ++i)
        {
            const float x = l[i], y = r[i];
            sLL_ += (x * x - sLL_) * a; sRR_ += (y * y - sRR_) * a; sLR_ += (x * y - sLR_) * a;
            msL_ = sLL_; msR_ = sRR_;
            pl = std::fmax (pl, std::fabs (x)); pr = std::fmax (pr, std::fabs (y));
        }
        pkL_ = undenorm (pl); pkR_ = undenorm (pr);
        sLL_ = undenorm (sLL_); sRR_ = undenorm (sRR_); sLR_ = undenorm (sLR_); msL_ = sLL_; msR_ = sRR_;
        if (! std::isfinite (sLL_ + sRR_ + sLR_)) { sLL_ = sRR_ = sLR_ = 0; }
    }
    double sr_ = 44100;
    Isolator iso_;
    bool isoOn_ = false; float isoMix_ = 0;
    float dcxL_ = 0, dcxR_ = 0, dcyL_ = 0, dcyR_ = 0;
    LR4 sideHP_, bassLP_; float lastBassHz_ = -1;
    Ramp gain_, width_, panL_, panR_, mute_;
    float sLL_ = 0, sRR_ = 0, sLR_ = 0, pkL_ = 0, pkR_ = 0, msL_ = 0, msR_ = 0;
    float mL_[1024], mR_[1024];                                   // process() is called with blocks of at most 1024
};
} // namespace sp
