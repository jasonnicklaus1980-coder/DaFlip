// DaFlip - a stereo utility for sampling on Gen1 MPC OS (VST2 insert effect, 32-bit ARM, no libstdc++).
// The DSP is in src/prep/Prep.h. This file: parameters, presets (VST programs), the status line and meters, entry points.
#include "prep/Prep.h"
#include "vst2.h"
#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <new>

#define DS_EXPORT extern "C" __attribute__((visibility("default")))

namespace
{
using namespace sp;

enum ParamId
{
    P_INMODE, P_INVL, P_INVR, P_DC, P_MONO, P_MSENC, P_WIDTH, P_BASSMONO, P_BASSHZ,
    P_GAIN, P_PAN, P_MUTE, P_LISTEN,
    P_ISOMODE, P_ISOPOS, P_ISOWIDTH, P_ISOSOFT, P_ISOLO, P_ISOHI, P_ISOSMOOTH,
    P_BYPASS,
    P_CORR, P_LEVEL,
    P_INFO,
    P_COUNT
};
enum Kind { K_FLOAT, K_CHOICE, K_BOOL, K_LOG, K_TEXT, K_METER };      // K_TEXT / K_METER: read-outs the plugin drives
enum Fmt { F_NUM, F_PCT, F_HZ, F_DB, F_PAN, F_CORR, F_METER };

const char* const kInModes[] { "Stereo", "Left", "Right", "Swap L/R" };
const char* const kListen[] { "Normal", "Mid (Mono)", "Side", "Bass" };
const char* const kIsoModes[] { "Off", "Keep", "Remove" };

struct ParamDef
{
    const char* key; const char* name; const char* unit; Kind kind; float lo, hi, step, def;
    const char* const* choices; int n; Fmt fmt;
};
#define CH(a) a, (int) (sizeof (a) / sizeof (a[0]))
ParamDef kParams[P_COUNT];
void initParams()
{
    auto f = [] (int i, const char* key, const char* name, const char* unit, Kind k, float lo, float hi, float step, float def, Fmt fm)
    { kParams[i] = { key, name, unit, k, lo, hi, step, def, nullptr, 0, fm }; };
    auto c = [] (int i, const char* key, const char* name, const char* const* ch, int n, int def)
    { kParams[i] = { key, name, "", K_CHOICE, 0, (float) (n - 1), 1, (float) def, ch, n, F_NUM }; };
    c (P_INMODE, "inmode", "Input", CH (kInModes), 0);
    f (P_INVL, "invl", "Phase L", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_INVR, "invr", "Phase R", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_DC, "dc", "DC Offset", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_MONO, "mono", "Mono", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_MSENC, "msenc", "Mid-Side", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_WIDTH, "width", "Width", "%", K_FLOAT, 0, 200, 1, 100, F_PCT);
    f (P_BASSMONO, "bassmono", "Bass Mono", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    f (P_BASSHZ, "basshz", "Bass Freq", "Hz", K_LOG, 40, 400, 0, 120, F_HZ);
    f (P_GAIN, "gain", "Gain", "dB", K_FLOAT, -60, 24, 0.1f, 0, F_DB);
    f (P_PAN, "pan", "Pan", "", K_FLOAT, -100, 100, 1, 0, F_PAN);
    f (P_MUTE, "mute", "Mute", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    c (P_LISTEN, "listen", "Listen", CH (kListen), 0);
    c (P_ISOMODE, "isomode", "Isolate", CH (kIsoModes), 0);
    f (P_ISOPOS, "isopos", "Position", "", K_FLOAT, -100, 100, 1, 0, F_PAN);
    f (P_ISOWIDTH, "isowidth", "Iso Width", "%", K_FLOAT, 2, 100, 1, 20, F_PCT);
    f (P_ISOSOFT, "isosoft", "Softness", "%", K_FLOAT, 0, 50, 1, 10, F_PCT);
    f (P_ISOLO, "isolo", "Low", "Hz", K_LOG, 20, 20000, 0, 20, F_HZ);
    f (P_ISOHI, "isohi", "High", "Hz", K_LOG, 20, 20000, 0, 20000, F_HZ);
    f (P_ISOSMOOTH, "isosmooth", "Smooth", "%", K_FLOAT, 0, 100, 1, 30, F_PCT);
    f (P_BYPASS, "bypass", "Bypass", "", K_BOOL, 0, 1, 1, 0, F_NUM);
    kParams[P_CORR] = { "corr", "Correlation", "", K_METER, 0, 1, 0, 1, nullptr, 0, F_CORR };
    kParams[P_LEVEL] = { "level", "Level", "", K_METER, 0, 1, 0, 0, nullptr, 0, F_METER };
    kParams[P_INFO] = { "info", "Status", "", K_TEXT, 0, 999, 1, 0, nullptr, 0, F_NUM };
}
inline bool isReadout (int i) { return kParams[i].kind == K_TEXT || kParams[i].kind == K_METER; }

float toPlain (const ParamDef& d, float norm)
{
    norm = clampf (norm, 0.f, 1.f);
    if (d.kind == K_BOOL) return norm >= 0.5f ? 1.f : 0.f;
    if (d.kind == K_CHOICE) return (float) (int) std::floor (norm * (float) (d.n - 1) + 0.5f);
    if (d.kind == K_LOG) return d.lo * std::pow (d.hi / d.lo, norm);
    float v = d.lo + norm * (d.hi - d.lo);
    if (d.step > 0.f) v = d.lo + std::floor ((v - d.lo) / d.step + 0.5f) * d.step;
    return clampf (v, d.lo, d.hi);
}
float toNorm (const ParamDef& d, float plain)
{
    if (d.kind == K_CHOICE) return d.n > 1 ? clampf (plain / (float) (d.n - 1), 0.f, 1.f) : 0.f;
    if (d.kind == K_LOG) return clampf (std::log (clampf (plain, d.lo, d.hi) / d.lo) / std::log (d.hi / d.lo), 0.f, 1.f);
    return clampf ((plain - d.lo) / (d.hi - d.lo), 0.f, 1.f);
}
void copyStr (void* dst, const char* src, size_t max = 24)
{
    if (dst == nullptr) return;
    std::strncpy ((char*) dst, src, max - 1);
    ((char*) dst)[max - 1] = 0;
}

// ---------------------------------------------------------------------------------------------- presets
struct Ov { int id; float v; };
struct Preset { const char* name; const Ov* ov; int n; };
#define PRESET(sym, ...) const Ov sym[] = { __VA_ARGS__ };
#define ENTRY(name, sym) { name, sym, (int) (sizeof (sym) / sizeof (sym[0])) }
PRESET (pClean, { P_GAIN, 0 })
PRESET (pLeft, { P_INMODE, 1 })
PRESET (pRight, { P_INMODE, 2 })
PRESET (pMonoCheck, { P_LISTEN, 1 })
PRESET (pBassMono, { P_BASSMONO, 1 }, { P_BASSHZ, 120 })
PRESET (pWide, { P_WIDTH, 150 })
PRESET (pIsoCentre, { P_ISOMODE, 1 }, { P_ISOPOS, 0 }, { P_ISOWIDTH, 12 }, { P_ISOSOFT, 8 })
PRESET (pVocalCut, { P_ISOMODE, 2 }, { P_ISOPOS, 0 }, { P_ISOWIDTH, 10 }, { P_ISOSOFT, 8 }, { P_ISOLO, 150 }, { P_ISOHI, 8000 })
PRESET (pIsoLeft, { P_ISOMODE, 1 }, { P_ISOPOS, -100 }, { P_ISOWIDTH, 20 })
PRESET (pIsoRight, { P_ISOMODE, 1 }, { P_ISOPOS, 100 }, { P_ISOWIDTH, 20 })
PRESET (pSides, { P_LISTEN, 2 })
PRESET (pBassOnly, { P_LISTEN, 3 }, { P_BASSHZ, 150 })
const Preset kPresets[] =
{
    ENTRY ("Clean", pClean), ENTRY ("Left Channel Only", pLeft), ENTRY ("Right Channel Only", pRight), ENTRY ("Mono Check", pMonoCheck),
    ENTRY ("Bass Mono 120 Hz", pBassMono), ENTRY ("Wide", pWide), ENTRY ("Isolate Centre", pIsoCentre), ENTRY ("Vocal Cut (Centre Out)", pVocalCut),
    ENTRY ("Isolate Hard Left", pIsoLeft), ENTRY ("Isolate Hard Right", pIsoRight), ENTRY ("Sides Only", pSides), ENTRY ("Bass Only", pBassOnly),
};
constexpr int kNumPresets = (int) (sizeof (kPresets) / sizeof (kPresets[0]));

// ---------------------------------------------------------------------------------------------- plugin
struct Text
{
    char buf[2][128] {}; std::atomic<int> live { 0 };
    const char* get() const { return buf[live.load()]; }
    bool publish (const char* s)
    {
        if (std::strcmp (get(), s) == 0) return false;
        const int idle = 1 - live.load(); std::snprintf (buf[idle], sizeof buf[idle], "%s", s); live.store (idle); return true;
    }
};

struct Plugin
{
    AEffect fx {};
    audioMasterCallback master = nullptr;
    std::atomic<float> v[P_COUNT], nv[P_COUNT];
    float sent[P_COUNT];
    int program = 0;
    float sr = 44100.f;
    Engine engine;
    Text info; int infoGen = 0;
    int displayCountdown = 0, meterCountdown = 0;
    static constexpr int kChunk = 1024;

    Plugin()
    {
        for (int i = 0; i < P_COUNT; ++i) { setPlain (i, kParams[i].def); sent[i] = 1e9f; }
        engine.prepare (sr);
        info.publish ("DaFlip: ready");
    }
    float get (int i) const { return v[i].load(); }
    void setPlain (int i, float plain) { v[i].store (plain); nv[i].store (toNorm (kParams[i], plain)); }
    void setNorm (int i, float norm)
    {
        if (isReadout (i)) return;
        const float p = toPlain (kParams[i], norm);
        v[i].store (p); nv[i].store (kParams[i].kind == K_FLOAT || kParams[i].kind == K_LOG ? clampf (norm, 0.f, 1.f) : toNorm (kParams[i], p));
    }
    void send (int i, float plain, float thr)                    // the plugin changes a value: tell the host (screen, Q-Links)
    {
        if (std::fabs (plain - sent[i]) < thr) return;
        sent[i] = plain;
        if (! isReadout (i)) setPlain (i, plain); else { v[i].store (plain); nv[i].store (toNorm (kParams[i], plain)); }
        if (master != nullptr) master (&fx, audioMasterAutomate, i, 0, nullptr, nv[i].load());
    }
    void applyPreset (int p)
    {
        if (p < 0 || p >= kNumPresets) return;
        program = p;
        for (int i = 0; i < P_COUNT; ++i) if (! isReadout (i) && i != P_BYPASS) setPlain (i, kParams[i].def);
        for (int k = 0; k < kPresets[p].n; ++k) setPlain (kPresets[p].ov[k].id, kPresets[p].ov[k].v);
    }
    void notifyHostAll()
    {
        if (master == nullptr) return;
        for (int i = 0; i < P_COUNT; ++i) if (! isReadout (i)) master (&fx, audioMasterAutomate, i, 0, nullptr, nv[i].load());
    }
    Settings settings() const
    {
        Settings s;
        s.inMode = (int) get (P_INMODE); s.invL = get (P_INVL) > 0.5f; s.invR = get (P_INVR) > 0.5f; s.dc = get (P_DC) > 0.5f;
        s.mono = get (P_MONO) > 0.5f; s.msEncode = get (P_MSENC) > 0.5f; s.width = get (P_WIDTH) / 100.f;
        s.bassMono = get (P_BASSMONO) > 0.5f; s.bassHz = get (P_BASSHZ);
        s.gainDb = get (P_GAIN); s.pan = get (P_PAN) / 100.f; s.mute = get (P_MUTE) > 0.5f; s.listen = (int) get (P_LISTEN);
        s.isoMode = (int) get (P_ISOMODE); s.isoPos = get (P_ISOPOS) / 100.f; s.isoWidth = get (P_ISOWIDTH) / 100.f;
        s.isoSoft = get (P_ISOSOFT) / 100.f; s.isoLo = get (P_ISOLO); s.isoHi = get (P_ISOHI); s.isoSmooth = get (P_ISOSMOOTH) / 100.f;
        s.bypass = get (P_BYPASS) > 0.5f;
        return s;
    }
    static void panText (float p, char* out, size_t max)
    {
        const int q = (int) std::lround (p);
        if (q == 0) std::snprintf (out, max, "C"); else std::snprintf (out, max, q < 0 ? "L %d" : "R %d", q < 0 ? -q : q);
    }
    static void hzText (float hz, char* out, size_t max)
    {
        if (hz >= 1000.f) std::snprintf (out, max, hz >= 9950.f ? "%.0f kHz" : "%.1f kHz", (double) hz / 1000.0);
        else std::snprintf (out, max, "%.0f Hz", (double) hz);
    }
    void updateDisplay()
    {
        char t[128], pre[32] = "";
        const int listen = (int) get (P_LISTEN);
        if (listen != 0) std::snprintf (pre, sizeof pre, "LISTEN %s | ", listen == 1 ? "MID" : (listen == 2 ? "SIDE" : "BASS"));
        const float c = engine.correlation();
        if (get (P_BYPASS) > 0.5f) std::snprintf (t, sizeof t, "BYPASS");
        else if (engine.isolating())
        {
            char ps[16], lo[16], hi[16];
            panText (get (P_ISOPOS), ps, sizeof ps); hzText (get (P_ISOLO), lo, sizeof lo); hzText (get (P_ISOHI), hi, sizeof hi);
            std::snprintf (t, sizeof t, "%s%s %s  width %.0f %%  %s-%s  (%.0f ms delay)", pre, get (P_ISOMODE) > 1.5f ? "REMOVE" : "ISOLATE", ps,
                           (double) get (P_ISOWIDTH), lo, hi, 1000.0 * engine.latency() / sr);
        }
        else if (! engine.hasSignal()) std::snprintf (t, sizeof t, "%sIN: no signal", pre);
        else if (c < -0.2f)
            std::snprintf (t, sizeof t, "%sPHASE WARNING %+.2f: cancels in mono, flip PHASE L or R", pre, (double) c);
        else
            std::snprintf (t, sizeof t, "%sL %.1f dB  R %.1f dB  CORREL %+.2f", pre, (double) engine.rmsDbL(), (double) engine.rmsDbR(), (double) c);
        if (! info.publish (t)) return;
        infoGen = (infoGen + 1) % 1000;
        send (P_INFO, (float) infoGen, 0.5f);
    }
    void process (const float* inL, const float* inR, float* outL, float* outR, int n)
    {
        const Settings s = settings();
        engine.process (inL, inR, outL, outR, n, s);
        fx.initialDelay = engine.latency();
        meterCountdown -= n;
        if (meterCountdown <= 0)
        {
            meterCountdown += (int) (sr / 20.f);
            send (P_CORR, (engine.correlation() + 1.f) * 0.5f, 0.0025f);     // 0.005 of correlation: reads as a number
            const float pk = std::fmax (engine.peakL(), engine.peakR());
            send (P_LEVEL, pk < 1e-6f ? 0.f : clampf ((20.f * std::log10 (pk) + 60.f) / 60.f, 0.f, 1.f), 0.015f);
        }
        displayCountdown -= n;
        if (displayCountdown <= 0) { displayCountdown += (int) (sr / 10.f); updateDisplay(); }
    }
    void display (int idx, char* out, size_t max)
    {
        const ParamDef& d = kParams[idx];
        const float p = get (idx);
        if (d.kind == K_TEXT) { std::snprintf (out, max, "%s", info.get()); return; }
        if (d.kind == K_CHOICE) { std::snprintf (out, max, "%s", d.choices[clampi ((int) p, 0, d.n - 1)]); return; }
        if (d.kind == K_BOOL) { std::snprintf (out, max, "%s", p > 0.5f ? "On" : "Off"); return; }
        switch (d.fmt)
        {
            case F_PCT: std::snprintf (out, max, "%.0f %%", (double) p); return;
            case F_HZ: hzText (p, out, max); return;
            case F_DB: if (p <= -60.f) std::snprintf (out, max, "-inf dB"); else std::snprintf (out, max, "%+.1f dB", (double) p); return;
            case F_PAN: panText (p, out, max); return;
            case F_CORR: std::snprintf (out, max, "%+.2f", (double) (p * 2.f - 1.f)); return;
            case F_METER: if (p <= 0.f) std::snprintf (out, max, "-inf dB"); else std::snprintf (out, max, "%.0f dB", (double) p * 60.0 - 60.0); return;
            default: std::snprintf (out, max, "%.2f", (double) p); return;
        }
    }
    static int clampi (int x, int lo, int hi) { return x < lo ? lo : (x > hi ? hi : x); }
};

// ---------------------------------------------------------------------------------------------- VST2 entry points
void processReplacing (AEffect* e, float** in, float** out, int32_t n)
{
    Plugin* p = static_cast<Plugin*> (e->object);
    for (int32_t pos = 0; pos < n; pos += Plugin::kChunk)
    {
        const int32_t m = (n - pos) < Plugin::kChunk ? (n - pos) : Plugin::kChunk;
        p->process (in[0] + pos, in[1] + pos, out[0] + pos, out[1] + pos, m);
    }
}
void processAccumulating (AEffect* e, float** in, float** out, int32_t n)
{
    float tl[256], tr[256];
    Plugin* p = static_cast<Plugin*> (e->object);
    for (int32_t pos = 0; pos < n; pos += 256)
    {
        const int32_t m = (n - pos) < 256 ? (n - pos) : 256;
        p->process (in[0] + pos, in[1] + pos, tl, tr, m);
        for (int32_t i = 0; i < m; ++i) { out[0][pos + i] += tl[i]; out[1][pos + i] += tr[i]; }
    }
}
void setParameter (AEffect* e, int32_t i, float norm) { if (i >= 0 && i < P_COUNT) static_cast<Plugin*> (e->object)->setNorm (i, norm); }
float getParameter (AEffect* e, int32_t i) { return (i >= 0 && i < P_COUNT) ? static_cast<Plugin*> (e->object)->nv[i].load() : 0.f; }
intptr_t dispatcher (AEffect* e, int32_t op, int32_t idx, intptr_t val, void* ptr, float opt)
{
    Plugin* p = static_cast<Plugin*> (e->object);
    switch (op)
    {
        case effClose:            p->~Plugin(); std::free (p); return 0;
        case effSetProgram:       p->applyPreset ((int) val); p->notifyHostAll(); return 0;
        case effGetProgram:       return p->program;
        case effGetProgramName:   copyStr (ptr, kPresets[p->program].name); return 0;
        case effGetProgramNameIndexed: if (idx < 0 || idx >= kNumPresets) return 0; copyStr (ptr, kPresets[idx].name); return 1;
        case effGetParamName:     if (idx >= 0 && idx < P_COUNT) copyStr (ptr, kParams[idx].name); return 0;
        case effGetParamLabel:    if (idx >= 0 && idx < P_COUNT) copyStr (ptr, kParams[idx].unit, 8); return 0;
        case effGetParamDisplay:  if (idx >= 0 && idx < P_COUNT && ptr != nullptr) { char b[128]; p->display (idx, b, sizeof b); copyStr (ptr, b, 64); } return 0;
        case effCanBeAutomated:   return (idx >= 0 && idx < P_COUNT && ! isReadout (idx)) ? 1 : 0;
        case effSetSampleRate:    if (opt > 1000.f) { p->sr = opt; p->engine.prepare (opt); } return 0;
        case effMainsChanged:     if (val) p->engine.prepare (p->sr); return 0;
        case effSetBypass:        p->setPlain (P_BYPASS, val ? 1.f : 0.f); return 1;
        case effGetEffectName:
        case effGetProductString: copyStr (ptr, "DaFlip", 32); return 1;
        case effGetVendorString:  copyStr (ptr, "ScratchLab", 32); return 1;
        case effGetVendorVersion: return 1000;
        case effGetPlugCategory:  return kPlugCategEffect;
        case effGetVstVersion:    return 2400;
        case effGetTailSize:      return 1;
        case effSetProcessPrecision: return val == 0 ? 1 : 0;
        case effCanDo:            return (ptr != nullptr && std::strcmp ((const char*) ptr, "bypass") == 0) ? 1 : 0;
        default: return 0;
    }
}
void initOnce() { static bool done = false; if (! done) { initParams(); done = true; } }
} // namespace

DS_EXPORT AEffect* VSTPluginMain (audioMasterCallback master)
{
    initOnce();
    void* mem = std::calloc (1, sizeof (Plugin));   // no operator new: keeps libstdc++ out of the link
    if (mem == nullptr) return nullptr;
    Plugin* p = new (mem) Plugin();
    p->master = master;
    p->applyPreset (0);
    AEffect& fx = p->fx;
    fx.magic = kEffectMagic;
    fx.dispatcher = dispatcher;
    fx.process = processAccumulating;
    fx.processReplacing = processReplacing;
    fx.setParameter = setParameter;
    fx.getParameter = getParameter;
    fx.numPrograms = kNumPresets;
    fx.numParams = P_COUNT;
    fx.numInputs = 2;
    fx.numOutputs = 2;
    fx.flags = effFlagsCanReplacing;
    fx.initialDelay = 0;
    fx.ioRatio = 1.f;
    fx.object = p;
    fx.uniqueID = ('D' << 24) | ('F' << 16) | ('L' << 8) | 'P';   // 'DFLP' = 0x44464C50
    fx.version = 1000;
    return &fx;
}
// stable parameter keys for tools/make_skin.py and the tests
DS_EXPORT const char* DS_ParamKey (int i) { initOnce(); return (i >= 0 && i < P_COUNT) ? kParams[i].key : ""; }
DS_EXPORT int DS_ParamCount() { return P_COUNT; }
DS_EXPORT const char* DS_PresetName (int i) { return (i >= 0 && i < kNumPresets) ? kPresets[i].name : ""; }
DS_EXPORT int DS_PresetCount() { return kNumPresets; }
