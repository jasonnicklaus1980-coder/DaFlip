# DaFlip (MPC)

A stereo utility for sampling, as a native **MPC OS VST2 insert effect** for Gen1 devices (MPC X, Live / Live II, One,
Key 61, Force), built on the same toolchain, installer, skin pipeline and GitHub workflow as DJ Scratch.

    input (stereo / left / right / swap) > phase L / R > DC removal > PAN ISOLATOR > width / mono > bass mono
    > mid-side encode > gain > balance > mute > listen (mid / side / bass) ; meters: level, phase correlation

- **Transparent when off**: bit-exact pass-through, zero latency.
- **Utility**: channel select / swap, polarity, DC removal, width 0-200 %, mono, M/S encode, bass mono (4th-order high-pass
  on the side only: the centre is untouched), gain, balance, mute; listen to mid (mono check), side or bass.
- **Pan isolator**: STFT (sqrt-Hann, 75 % overlap, 2048 points at 44.1/48 kHz, 4096 at 96 kHz); one complex FFT of L + iR
  per hop gives both channel spectra; each bin's position is the angle of |R| vs |L|; keep or remove a position window with
  soft edges, within a frequency range, smoothed over time. Same real gain on both channels, so what's kept keeps its
  stereo placement. ~46 ms latency while on (reported to the host), none when off.
- **Meters**: phase correlation (with a status-line warning when the sides cancel in mono), level.
- Two screen pages (UTILITY, ISOLATE); see `docs/skin-preview-*.png`. 12 presets.
- No threads, no files, no allocation on the audio path; denormal-safe; libc + libm only, glibc <= 2.29.

## Layout
    src/prep/Prep.h       the DSP (utility chain, FFT, isolator, meters)
    src/daflip.cpp    VST2 entry points, parameters, presets, status line and meters
    src/vst2.h            minimal VST2 ABI header (shared with DJ Scratch)
    tools/make_skin.py    the MPC touchscreen skin (run `make native` first)
    mpc/                  installer, uninstaller, setup.sh, plugin entry, manual (INSTALL.md)
    scripts/              package.sh (build + verify + zip), verify_arm.sh, build_mpc.sh, deploy.sh
    test/                 engine_test (DSP, ASan + UBSan), host_test (the plugin as the MPC loads it, + soak), abi32_check

## Build + test
    make test        # DSP tests under ASan/UBSan + the plugin through a VST2 host harness
    make soak        # the host test with a 10-minute random-use soak
    ./scripts/package.sh      # ARM build (cross-compiler or Docker), verification, release zip
    ./scripts/build_mpc.sh <mpc-ip>    # build and install over SSH from a computer
GitHub from a phone: see GITHUB.md.

## Status
Tested here, on x86: engine_test 37 checks (bit-exact transparency at any block size; input modes, phase, mono, width,
M/S exact; bass mono -31 dB on 50 Hz sides, 0.00 dB on 1 kHz sides, centre untouched; DC, gain, balance, mute, listen;
isolator perfect reconstruction to 2e-7, separation of test tones by position >80 dB in KEEP and REMOVE, by frequency range,
placement preserved, on / off back to bit-exact, 48 and 96 kHz; correlation meter; no zipper noise; 400 random settings
finite) and host_test 39 checks (interface, displays, presets, monitoring bit-exact at 44.1 / 48 / 96 kHz x 9 block sizes x
separate / in-place buffers, every feature through the real parameters with clean monitoring after each, latency reporting,
correlation read-out and phase warning, bypass while isolating, rate changes, two instances, 30 open / close cycles, a
10-minute random-use soak). Also under AddressSanitizer + UBSan with no errors or leaks; installer / upgrade / uninstall in a
fake MPC root next to DJ Scratch. CPU on a desktop core: 0.07 % utility, 0.8 % with the isolator at 44.1 / 48 kHz.

Not tested on a device: the ARM build (built and verified by the GitHub workflow), CPU on the MPC's ARM cores, and how well
real records separate (test tones separate by >80 dB; real mixes far less, depending on how they were panned).
