# DaFlip 1.0

A stereo utility for sampling on the MPC: pick or swap channels, fix phase, remove DC, narrow / widen / mono, put the bass
in mono, and **pull a single instrument out of a stereo record by where it sits between left and right** (or cut it out).
A native MPC OS VST2 insert effect with a two-page touchscreen skin, by ScratchLab (the makers of DJ Scratch).

## Install
Same as DJ Scratch. Build on GitHub (GITHUB.md): upload `DaFlip-MPC-source.zip` and the workflow, wait for the green
check, then in Termius on the MPC:

    cd /tmp
    wget -O setup.sh https://github.com/<you>/<repo>/releases/latest/download/setup.sh
    wget -O DaFlip-1.0.0-mpc-armv7.zip https://github.com/<you>/<repo>/releases/latest/download/DaFlip-1.0.0-mpc-armv7.zip
    sh setup.sh

Save your project first: the installer restarts MPC. DaFlip installs next to DJ Scratch and doesn't touch it.
Uninstall: `sh /tmp/DaFlip-1.0.0/uninstall.sh` (removes only DaFlip).

## Where to put it
- **Sampling:** in the MPC **Sampler's INSERTS** (turn the Sampler's monitor on). What you hear is what gets sampled.
- **Before DJ Scratch:** put DaFlip first, then DJ Scratch, to scratch just the isolated part.
- Anywhere else: a track, a pad, a program, a submix or the master.

With everything off it changes nothing at all (the output is the input, bit for bit, with no delay).

## UTILITY page
- **Input:** Stereo, Left (left on both sides), Right (right on both sides), Swap L/R. On old hard-panned stereo records,
  Left or Right alone often gives you just the drums or just the band.
- **PHASE L / PHASE R:** flip one side's polarity. Use it when the correlation meter goes left (red): the two sides cancel each
  other when summed to mono, and the sample sounds thin.
- **DC OFFSET:** removes a constant offset some old gear and transfers leave in (it makes pads click and eats headroom).
- **MONO, Width (0-200 %):** mono, narrower, or wider. **MID-SIDE** turns the output into mid (left) and side (right).
- **BASS MONO + frequency (40-400 Hz):** everything below the frequency becomes mono, so the low end sits solid in the centre.
  Only the sides' low end is touched; centred bass and kick pass exactly as they were.
- **Gain** (-60 to +24 dB), **Pan** (balance), **MUTE**.
- **Listen:** Normal; **Mid (Mono)** = how the sample sounds summed to mono; **Side** = only what differs between left and
  right (the centre disappears); **Bass** = only the low end, below the Bass frequency. Listen also changes what gets sampled
  (handy to sample only the sides, or only the bass).
- **Level** and **Correlation** meters: correlation +1 = left and right identical (mono-safe), 0 = unrelated (wide),
  below 0 = they cancel in mono. The status line warns: *PHASE WARNING -0.62: cancels in mono, flip PHASE L or R*.
- **BYPASS:** everything off at once.

## ISOLATE page: pull an instrument out of the stereo mix
The isolator looks at the sound in thousands of thin frequency slices and works out where each one sits between left and
right. You choose a position; it keeps (or removes) what sits there.

1. **Mode:** *Keep* (only the chosen position) or *Remove* (everything except it). *Off* = no isolation.
2. **POSITION:** drag the big slider (or turn Q-Link 1) across the stereo field, L 100 ... C ... R 100, until the instrument you
   want stands out.
3. **Width:** how wide a slice of the field to keep (2-100 %). Narrower = more separation; too narrow sounds watery.
4. **Softness:** how gently the edges fade (0-50 %). **Smooth:** how slowly the separation reacts (0-100 %); more = less watery.
5. **Low / High:** only work on this frequency range, e.g. *Remove* centre between 150 Hz and 8 kHz takes out a lead vocal but
   leaves the kick, bass and cymbals.

Presets do the common jobs: Isolate Centre, Vocal Cut (Centre Out), Isolate Hard Left, Isolate Hard Right, Sides Only,
Bass Only, Left / Right Channel Only, Mono Check, Bass Mono 120 Hz, Wide, Clean.

**What to expect.** It works best on records where instruments were panned apart (a lot of 60s and early 70s stereo, live
recordings, breaks with the drums to one side). On modern mixes most things sit near the centre, so they separate less.
Two instruments in the same place can't be told apart by position; reverb spreads a sound across positions; and mono
records have nothing to separate. AI "stem splitting" (vocals / drums / bass from any mix) needs far more computing power
than the MPC has for real time.

**Delay.** While the isolator is on, the sound comes out about 46 ms late (it has to analyse a short stretch at a time). The
status line shows it. That doesn't matter for sampling; switch the isolator off (Mode Off) and the delay is gone.

## Q-Links
| Page | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| UTILITY | Width | Gain | Pan | Bass freq | Input | Listen | Phase L | Phase R | Mono | Mid-Side | Bass Mono | DC |
| ISOLATE | Position | Width | Softness | Smooth | Low | High | Mode | Listen | Gain | Width (stereo) | Mute | Bypass |

## Troubleshooting
- Plugin does not appear: it is listed after MPC restarts. Check `grep daflip /media/az01-internal/Settings/*/MPC.settings`.
- Plain parameter list instead of the skin: the skin lives in `/sdcard/Synths/ScratchLab - VST - DaFlip`.
- Isolating sounds watery: widen Width, raise Softness and Smooth, or narrow the frequency range to the instrument.
- No sound: check MUTE, Gain (-inf at the bottom), Listen (Side on a mono record is silence), and the Sampler's monitor.
