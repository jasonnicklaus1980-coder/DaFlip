#!/usr/bin/env python3
"""Generate the DaFlip MPC screen skin (the same skin pipeline and MPC rules as DJ Scratch and the SP1200 skin).

Two pages (MPC screen tabs):
  UTILITY  input (stereo / left / right / swap, phase L / R, DC), stereo (mono, mid-side, width), bass mono + frequency,
           output (gain, pan, mute), listen (mid = mono check, side, bass), a correlation meter and a level meter
  ISOLATE  the pan isolator: a big horizontal POSITION slider across the stereo field (L ... C ... R), mode (off / keep /
           remove), width, softness, smoothing, the frequency range; listen, meters and bypass
Every control is bound to "Parameter N"; the indices come from the built plugin (DS_ParamKey), so run `make native` first.
MPC rules (proven with DJ Scratch and the SP1200 skin): square filmstrip frames, 128 frames, numFrames = last frame index
(127), pieces at most 84 px wide, each piece fully inside its control.  Requires Pillow.
Usage: python3 tools/make_skin.py [preview-dir]
"""
import ctypes, json, math, os, random, shutil, sys
from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SKIN_NAME = "ScratchLab - VST - DaFlip"          # MPC looks for "<manufacturer> - VST - <plugin name>"
SKIN_DIR = os.path.join(ROOT, "mpc", "skin", SKIN_NAME)
OUT = os.path.join(SKIN_DIR, "Plugin Skins")
W, H = 1280, 628
FRAMES, NUMFRAMES, SS = 128, 127, 4

FONT_DIRS = ["/usr/share/fonts/truetype/dejavu", "/usr/share/fonts/dejavu", "/Library/Fonts", "C:/Windows/Fonts"]
def font(size, name="DejaVuSans-Bold.ttf"):
    for d in FONT_DIRS:
        p = os.path.join(d, name)
        if os.path.exists(p): return ImageFont.truetype(p, size)
    return ImageFont.load_default()

# ---------- palette: graphite panel, steel strips, teal light ----------
BODY    = (22, 25, 28)
STRIP   = (176, 184, 190)
INK     = (18, 18, 20)
PRINT   = (226, 232, 234)
PRINT_DIM = (140, 152, 158)
RULE    = (104, 118, 124)
AMBER   = (40, 214, 196)          # the accent (named AMBER in the shared helpers): teal here
KEYFACE, KEYFACE_DN = (42, 47, 52), (28, 32, 36)
LCD_BG  = (10, 14, 15)
LCD_TXT = (40, 214, 196)
FOCUS_COL, LCD_COL, VALUE_COL = "ff28d6c4", "ff28d6c4", "ffffffff"
PLINTH = (34, 38, 44)

def rgba(c, a=255): return (c[0], c[1], c[2], a)
def mix(a, b, t): return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))
def text_c(d, cx, cy, s, f, fill):
    b = d.textbbox((0, 0), s, font=f); d.text((cx - (b[2] - b[0]) / 2 - b[0], cy - (b[3] - b[1]) / 2 - b[1]), s, font=f, fill=fill)
def spaced(s, n=1): return (" " * n).join(s)

# ---------- keys: a rubber key with a steel bezel and an amber LED bar ----------
KEY_W, KEY_H = 64, 66
BIG_W = 112
def key_image(on, w=KEY_W, h=KEY_H):
    s = SS
    im = Image.new("RGBA", (w * s, h * s), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    cx = w * s / 2; kw, kt, kb = (w / 2 - 13) * s, 16 * s, 46 * s
    lw, lh, ly = min(14, w / 2 - 18) * s, 2.5 * s, 7 * s
    if on:
        g = Image.new("RGBA", im.size, (0, 0, 0, 0))
        ImageDraw.Draw(g).rounded_rectangle([cx - lw - 4 * s, ly - 6 * s, cx + lw + 4 * s, ly + 6 * s], radius=5 * s, fill=(40, 214, 196, 150))
        im.alpha_composite(g.filter(ImageFilter.GaussianBlur(3 * s))); d = ImageDraw.Draw(im)
    d.rounded_rectangle([cx - lw, ly - lh, cx + lw, ly + lh], radius=2 * s, fill=rgba(AMBER if on else (20, 62, 58)))
    d.rounded_rectangle([cx - kw + 2 * s, kt + 3 * s, cx + kw + 2 * s, kb + 3 * s], radius=3 * s, fill=(0, 0, 0, 120))
    off = 2 * s if on else 0
    face = KEYFACE_DN if on else KEYFACE
    d.rounded_rectangle([cx - kw - 2 * s, kt + off - 2 * s, cx + kw + 2 * s, kb + off + 2 * s], radius=4 * s, fill=rgba((150, 156, 166)))
    d.rounded_rectangle([cx - kw, kt + off, cx + kw, kb + off], radius=3 * s, fill=rgba(face))
    for k in range(6):
        yy = kt + off + (5 + k * 4) * s
        d.line([cx - kw + 5 * s, yy, cx + kw - 5 * s, yy], fill=rgba(mix(face, (0, 0, 0), 0.35)), width=s)
    d.line([cx - kw + 3 * s, kt + off + s, cx + kw - 3 * s, kt + off + s], fill=rgba(mix(face, (255, 255, 255), 0.18)), width=s)
    return im.resize((w, h), Image.LANCZOS)

# ---------- the input meter: 3 square 42 px pieces side by side, 15 segments ----------
MP, MN = 42, 3
def meter_strips():
    strips = [Image.new("RGBA", (MP, MP * FRAMES), (0, 0, 0, 0)) for _ in range(MN)]
    segs = 15; wtot = MP * MN
    for f in range(FRAMES):
        lvl = f / (FRAMES - 1)
        fr = Image.new("RGBA", (wtot * SS, MP * SS), (0, 0, 0, 0)); d = ImageDraw.Draw(fr)
        for k in range(segs):
            x0 = (4 + k * (wtot - 8) / segs) * SS; x1 = x0 + ((wtot - 8) / segs - 2) * SS
            lit = (k + 0.5) / segs <= lvl
            col = (90, 200, 120) if k < 10 else (AMBER if k < 13 else (230, 60, 50))
            d.rounded_rectangle([x0, 12 * SS, x1, 30 * SS], radius=SS, fill=rgba(col if lit else mix(col, (0, 0, 0), 0.8)))
        fr = fr.resize((wtot, MP), Image.LANCZOS)
        for k in range(MN): strips[k].paste(fr.crop((k * MP, 0, (k + 1) * MP, MP)), (0, f * MP))
    return strips


# ---------- correlation meter: 4 square 42 px pieces side by side, a needle from -1 (cancels) to +1 (mono-safe) ----------
CP, CN = 42, 4
def corr_strips():
    strips = [Image.new("RGBA", (CP, CP * FRAMES), (0, 0, 0, 0)) for _ in range(CN)]
    wtot = CP * CN
    for f in range(FRAMES):
        v = f / (FRAMES - 1)
        fr = Image.new("RGBA", (wtot * SS, CP * SS), (0, 0, 0, 0)); d = ImageDraw.Draw(fr)
        x0, x1, y0, y1 = 6 * SS, (wtot - 6) * SS, 17 * SS, 25 * SS
        mid = (x0 + x1) / 2
        d.rounded_rectangle([x0, y0, mid, y1], radius=2 * SS, fill=rgba((150, 52, 48)))
        d.rounded_rectangle([mid, y0, x1, y1], radius=2 * SS, fill=rgba(mix(AMBER, (0, 0, 0), 0.45)))
        d.line([mid, 12 * SS, mid, 30 * SS], fill=rgba(PRINT), width=SS)
        nx = x0 + (x1 - x0) * v
        col = (255, 90, 80) if v < 0.4 else AMBER
        d.rounded_rectangle([nx - 2.5 * SS, 8 * SS, nx + 2.5 * SS, 34 * SS], radius=SS, fill=rgba(col))
        fr = fr.resize((wtot, CP), Image.LANCZOS)
        for k in range(CN): strips[k].paste(fr.crop((k * CP, 0, (k + 1) * CP, CP)), (0, f * CP))
    return strips

# ---------- the POSITION slider: 6 square 84 px pieces across the stereo field, dragged sideways ----------
PP, PN, PLAB = 84, 6, 22
def pos_strips():
    strips = [Image.new("RGBA", (PP, PP * FRAMES), (0, 0, 0, 0)) for _ in range(PN)]
    wtot = PP * PN
    for f in range(FRAMES):
        v = f / (FRAMES - 1)
        fr = Image.new("RGBA", (wtot * SS, PP * SS), (0, 0, 0, 0)); d = ImageDraw.Draw(fr)
        x0, x1 = 20 * SS, (wtot - 20) * SS
        cx = x0 + (x1 - x0) * v
        glow = Image.new("RGBA", fr.size, (0, 0, 0, 0))
        ImageDraw.Draw(glow).rounded_rectangle([cx - 40 * SS, 18 * SS, cx + 40 * SS, 66 * SS], radius=10 * SS, fill=rgba(AMBER, 90))
        fr.alpha_composite(glow.filter(ImageFilter.GaussianBlur(6 * SS))); d = ImageDraw.Draw(fr)
        d.rounded_rectangle([cx - 14 * SS, 16 * SS, cx + 14 * SS, 68 * SS], radius=5 * SS, fill=rgba((150, 160, 166)))
        d.rounded_rectangle([cx - 12 * SS, 18 * SS, cx + 12 * SS, 66 * SS], radius=4 * SS, fill=rgba((58, 64, 70)))
        d.rectangle([cx - 1.5 * SS, 22 * SS, cx + 1.5 * SS, 62 * SS], fill=rgba(AMBER))
        fr = fr.resize((wtot, PP), Image.LANCZOS)
        for k in range(PN): strips[k].paste(fr.crop((k * PP, 0, (k + 1) * PP, PP)), (0, f * PP))
    return strips
# ---------- TUI.json (same schema as the SP1200 / GlueBus skins) ----------
NOREMAP = {"version": 1, "map": []}
def bounds(b, focus="No", show="Show", visible="Always"):
    return {"version": 2, "acceptsHWFocus": focus, "showWhenDataModelInvalid": show, "whenVisible": visible,
            "boundsType": "Absolute", "bounds": " ".join(str(int(v)) for v in b), "additionalInvalidatingHandles": []}
def comp(name, typ, data, b, remap=None):
    return {"version": 2, "componentData": {"version": 1, "name": name, "type": typ, "data": data},
            "handle remapping": remap or NOREMAP, "bounds": b}
def action(on, handler, extra=""):
    return {"version": 2, "onAction": on, "handler": handler, "handleName": "" if handler == "Show Overlay" else "Data",
            "additionalData": extra, "handle remapping": NOREMAP}
def bgdata(col="0"): return {"version": 1, "focussed": {"version": 1, "colour": col, "image": ""}, "unfocussed": {"version": 1, "colour": col, "image": ""}}
def definition(actions, parts, bgcol="0", ignore=False):
    return {"version": 4, "actions": actions, "backgroundData": bgdata(bgcol), "ignoreMousePresses": ignore,
            "disableCoarseDataWheel": False, "repeats": 1, "hideQLinkBounds": True, "componentsData": parts}
def label(kind, h, colour, b, case="Original", name=None):
    return comp(name or kind, "Label", {"version": 1, "textStyle": {"version": 1, "font": {"version": 1, "name": "Titillium Web", "style": "SemiBold", "height": float(h)},
                "colour": colour, "justification": "horizontallyCentred verticallyCentred", "case": case}, "type": kind, "handleName": "Data"}, bounds(b))
def focus(b):
    return comp("Focus", "Focus", {"version": 1, "backgroundColour": "00000000", "outlineColour": FOCUS_COL, "backgroundInset": 2.0, "outlineThickness": 2.0},
                bounds(b, visible="WhenFocussed"))

# ---------- parameter indices from the built plugin ----------
LIB = os.path.join(ROOT, "build", "native", "daflip.so")
def load_keys():
    lib = ctypes.CDLL(LIB)
    lib.DS_ParamKey.restype = ctypes.c_char_p; lib.DS_ParamKey.argtypes = [ctypes.c_int]
    lib.DS_ParamCount.restype = ctypes.c_int
    return {lib.DS_ParamKey(i).decode(): i for i in range(lib.DS_ParamCount())}
P = load_keys()

# ---------- layout ----------
TABS = ["UTILITY", "ISOLATE"]
BG_ITEMS = {t: [] for t in TABS}
PLACED = {t: [] for t in TABS}
DEFS, IMAGES = {}, {}
def img(name, im): IMAGES[name] = im; return name
def defn(key, value): DEFS.setdefault(key, value); return key
def place(tab, name, dkey, param, x, y, w, h, kind, extra=None, touch=True):
    PLACED[tab].append(dict(name=name, dkey=dkey, param=param, x=x, y=y, w=w, h=h, kind=kind, extra=extra, touch=touch))

DRAG = "ds_drag.png"
def drag_strip(sq=16): return Image.new("RGBA", (sq, sq * FRAMES), (0, 0, 0, 0))
CTRL = lambda: [action("Mouse Down", "Q-Link"), action("Double Click", "Show Overlay", "knob overlay"), action("Enter Pressed", "Show Overlay", "knob overlay")]
def drag_knobs(w, h, orient="Vertical"):
    """An invisible drag area made the way the MPC accepts it: a grid of square knob pieces (<= 84 px, square filmstrip
    frames, each fully inside the control), all bound to the same parameter, like the pitch fader's pieces."""
    sq = int(min(84, h, w))
    nx, ny = max(1, w // sq), max(1, h // sq)
    x0, y0 = (w - nx * sq) // 2, (h - ny * sq) // 2
    strip = img(f"ds_drag{sq}.png", Image.new("RGBA", (sq, sq * FRAMES), (0, 0, 0, 0)))
    return [comp("Knob", "Knob", {"version": 5, "knobType": "FilmStrip", "filmStrip": strip, "numFrames": NUMFRAMES, "invert": False,
                 "dragOrientation": orient, "handleName": "Data"}, bounds((x0 + i * sq, y0 + j * sq, sq, sq)))
            for j in range(ny) for i in range(nx)]
def d_box(w, h, fs=17):
    key = f"dsBox{w}x{h}_{fs}"
    return defn(key, definition(CTRL(), drag_knobs(w, h) + [label("Value", fs, LCD_COL, (0, 0, w, h), case="Upper Case"), focus((0, 0, w, h))]))
def d_text(w, h, fs, col=LCD_COL):
    return defn(f"dsText{w}x{h}_{fs}", definition([], [label("Value", fs, col, (0, 0, w, h))], ignore=True))
def d_zone(w, h):
    return defn(f"dsZone{w}x{h}", definition([action("Mouse Down", "Q-Link")], drag_knobs(w, h)))

def section(tab, x0, x1, y, title): BG_ITEMS[tab].append(("section", x0, x1, y, title))
def box(tab, name, key, x, y, w=186, h=44, caption=None, fs=17):
    place(tab, name, d_box(w, h, fs), P[key], x, y, w, h, "box")
    BG_ITEMS[tab].append(("lcd", x, y, w, h, caption))
def text(tab, name, key, x, y, w, h, fs=15):
    place(tab, name, d_text(w, h, fs), P[key], x, y, w, h, "text", fs, touch=False)
def keycap(tab, name, key, x, y, cap, big=False):
    place(tab, name, "dsBigKey" if big else "dsKey", P[key], x, y, BIG_W if big else KEY_W, KEY_H, "bigkey" if big else "key")
    BG_ITEMS[tab].append(("cap", x + (BIG_W if big else KEY_W) / 2, y + KEY_H + 10, cap))
def meter(tab, x, y, cap="INPUT"):
    place(tab, "Level", "dsMeter", P["level"], x, y, MP * MN, MP, "meter", touch=False)
    BG_ITEMS[tab].append(("meterbg", x, y, cap))
def status(tab, x, y, w, h, fs=20):
    BG_ITEMS[tab].append(("lcd", x, y, w, h, None))
    text(tab, "Status", "info", x + 6, y + 4, w - 12, h - 8, fs)

# ---------- shared component definitions ----------
img("ds_key_on.png", key_image(True)); img("ds_key_off.png", key_image(False))
img("ds_bigkey_on.png", key_image(True, BIG_W)); img("ds_bigkey_off.png", key_image(False, BIG_W))
def keydef(name, on, off, w):
    defn(name, definition([action("Mouse Down", "Q-Link"), action("Enter Pressed", "Toggle Switch")], [
        focus((0, 0, w, KEY_H)),
        comp("Button", "Button", {"version": 2, "onImage": on, "offImage": off, "buttonId": 1,
             "numButtonsInGroup": 1, "handleName": "Data", "gestureBehaviour": "Instant"}, bounds((0, 0, w, KEY_H)))]))
keydef("dsKey", "ds_key_on.png", "ds_key_off.png", KEY_W)
keydef("dsBigKey", "ds_bigkey_on.png", "ds_bigkey_off.png", BIG_W)
for k, st in enumerate(meter_strips()): img(f"ds_meter{k}.png", st)
defn("dsMeter", definition([], [comp("Knob", "Knob", {"version": 5, "knobType": "FilmStrip", "filmStrip": f"ds_meter{k}.png", "numFrames": NUMFRAMES,
     "invert": False, "dragOrientation": "Horizontal", "handleName": "Data"}, bounds((k * MP, 0, MP, MP))) for k in range(MN)], ignore=True))

for k, st in enumerate(corr_strips()): img(f"sp_corr{k}.png", st)
defn("spCorr", definition([], [comp("Knob", "Knob", {"version": 5, "knobType": "FilmStrip", "filmStrip": f"sp_corr{k}.png", "numFrames": NUMFRAMES,
     "invert": False, "dragOrientation": "Horizontal", "handleName": "Data"}, bounds((k * CP, 0, CP, CP))) for k in range(CN)], ignore=True))
for k, st in enumerate(pos_strips()): img(f"sp_pos{k}.png", st)
PW, PH = PP * PN, PLAB + PP
defn("spPos", definition(CTRL(), [focus((0, 0, PW, PH))] + [comp("Knob", "Knob", {"version": 5, "knobType": "FilmStrip", "filmStrip": f"sp_pos{k}.png",
     "numFrames": NUMFRAMES, "invert": False, "dragOrientation": "Horizontal", "handleName": "Data"}, bounds((k * PP, PLAB, PP, PP))) for k in range(PN)]
     + [label("Value", 15, LCD_COL, (0, 0, PW, PLAB), case="Upper Case")]))
def corr(tab, x, y, cap="CORRELATION"):
    place(tab, "Correlation", "spCorr", P["corr"], x, y, CP * CN, CP, "corr", touch=False)
    BG_ITEMS[tab].append(("corrbg", x, y, cap))

# ================================================================= UTILITY page
T = "UTILITY"
section(T, 24, 620, 52, "Input")
keycap(T, "Phase L", "invl", 24, 86, "PHASE L")
keycap(T, "Phase R", "invr", 104, 86, "PHASE R")
keycap(T, "DC Offset", "dc", 184, 86, "DC OFFSET")
box(T, "Input", "inmode", 300, 112, w=200, caption="Input  (stereo / left / right / swap)")
section(T, 660, 1256, 52, "Stereo")
keycap(T, "Mono", "mono", 660, 86, "MONO")
keycap(T, "Mid-Side", "msenc", 740, 86, "MID-SIDE")
box(T, "Width", "width", 840, 112, w=200, caption="Width")
section(T, 24, 620, 200, "Bass")
keycap(T, "Bass Mono", "bassmono", 24, 234, "BASS MONO")
box(T, "Bass Freq", "basshz", 120, 260, w=200, caption="Bass Mono below")
section(T, 660, 1256, 200, "Output")
keycap(T, "Mute", "mute", 660, 234, "MUTE")
box(T, "Gain", "gain", 760, 260, w=170, caption="Gain")
box(T, "Pan", "pan", 950, 260, w=170, caption="Pan")
section(T, 24, 1256, 348, "Listen and meters")
box(T, "Listen", "listen", 24, 410, w=200, caption="Listen")
meter(T, 270, 412, "LEVEL")
corr(T, 450, 412, "CORRELATION  (left = cancels in mono)")
keycap(T, "Bypass", "bypass", 700, 386, "BYPASS")
status(T, 24, 500, 1232, 56, fs=18)

# ================================================================= ISOLATE page
T = "ISOLATE"
section(T, 24, 1256, 52, "Pan isolator  (pull one instrument out of a stereo record, or cut it)")
box(T, "Mode", "isomode", 24, 128, w=170, caption="Mode")
place(T, "Position", "spPos", P["isopos"], 226, 86, PW, PH, "pos")
BG_ITEMS[T].append(("posbg", 226, 86 + PLAB))
box(T, "Iso Width", "isowidth", 774, 128, w=150, caption="Width")
box(T, "Softness", "isosoft", 940, 128, w=150, caption="Softness")
box(T, "Smooth", "isosmooth", 1106, 128, w=150, caption="Smooth")
section(T, 24, 620, 236, "Frequency range")
box(T, "Low", "isolo", 24, 296, caption="Low")
box(T, "High", "isohi", 229, 296, caption="High")
section(T, 660, 1256, 236, "Listen and meters")
box(T, "Listen", "listen", 660, 296, w=170, caption="Listen")
meter(T, 852, 298, "LEVEL")
corr(T, 1010, 298, "CORRELATION")
BG_ITEMS[T].append(("legend", 24, 372, ["Sweep POSITION until the instrument stands out, narrow WIDTH, then REMOVE to cut it instead."]))
status(T, 24, 420, 1232, 56, fs=18)

QL = {
    "UTILITY": ["width", "gain", "pan", "basshz", "inmode", "listen", "invl", "invr", "mono", "msenc", "bassmono", "dc"],
    "ISOLATE": ["isopos", "isowidth", "isosoft", "isosmooth", "isolo", "isohi", "isomode", "listen", "gain", "width", "mute", "bypass"],
}

# ---------- backgrounds ----------
def brushed(w, h, base, seed, amp=5, vertical=False):
    random.seed(seed)
    im = Image.new("RGB", (w, h), base); d = ImageDraw.Draw(im)
    for i in range(h if not vertical else w):
        n = random.randint(-amp, amp); c = (base[0] + n, base[1] + n, base[2] + n)
        if vertical: d.line([i, 0, i, h], fill=c)
        else: d.line([0, i, w, i], fill=c)
    return im

def panel_bg(title_right):
    random.seed(7)
    im = Image.new("RGB", (W, H), BODY); px = im.load()
    for y in range(H):
        for x in range(W):
            n = random.randint(-2, 2); px[x, y] = (BODY[0] + n, BODY[1] + n, BODY[2] + n)
    d = ImageDraw.Draw(im)
    for (y0, y1) in ((0, 40), (H - 26, H)):
        im.paste(brushed(W, y1 - y0, STRIP, 5 + y0, amp=6), (0, y0))
    d = ImageDraw.Draw(im)
    d.line([0, 40, W, 40], fill=(90, 94, 102), width=2); d.line([0, H - 26, W, H - 26], fill=(90, 94, 102), width=2)
    d.line([0, 41, W, 41], fill=(226, 230, 236), width=1)
    d.text((24, 6), "DAFLIP", font=font(24), fill=INK)
    d.text((150, 15), spaced("SCRATCHLAB  STEREO  UTILITY  FOR  SAMPLING", 2), font=font(9), fill=INK)
    tw = d.textlength(spaced(title_right), font=font(13)); d.text((W - 24 - tw, 13), spaced(title_right), font=font(13), fill=INK)
    d.text((24, H - 20), "ScratchLab", font=font(12, "DejaVuSans.ttf"), fill=INK)
    return im, d

def background(tab):
    im, d = panel_bg(tab)
    for item in BG_ITEMS[tab]:
        k = item[0]
        if k == "section":
            _, x0, x1, y, title = item
            d.text((x0, y), title, font=font(17, "DejaVuSans.ttf"), fill=PRINT)
            d.line([x0, y + 26, x1, y + 26], fill=RULE, width=2)
        elif k == "lcd":
            _, x, y, w, hh, cap = item
            d.rounded_rectangle([x - 5, y - 5, x + w + 5, y + hh + 5], radius=5, fill=(150, 156, 166))
            d.rounded_rectangle([x - 3, y - 3, x + w + 3, y + hh + 3], radius=4, fill=(8, 9, 11))
            d.rectangle([x, y, x + w, y + hh], fill=LCD_BG)
            if cap: d.text((x, y - 26), cap, font=font(13, "DejaVuSans.ttf"), fill=PRINT_DIM)
        elif k == "meterbg":
            _, x, y, cap = item
            d.rounded_rectangle([x - 4, y - 2, x + MP * MN + 4, y + MP + 2], radius=5, fill=(8, 9, 11), outline=(90, 96, 106))
            d.text((x, y - 24), cap, font=font(13, "DejaVuSans.ttf"), fill=PRINT_DIM)
        elif k == "corrbg":
            _, x, y, cap = item
            d.rounded_rectangle([x - 4, y - 2, x + CP * CN + 4, y + CP + 2], radius=5, fill=(8, 10, 11), outline=(80, 92, 98))
            d.text((x, y - 24), cap, font=font(13, "DejaVuSans.ttf"), fill=PRINT_DIM)
        elif k == "posbg":
            _, x, y = item
            d.rounded_rectangle([x, y, x + PW, y + PP], radius=10, fill=(12, 15, 17), outline=(80, 92, 98), width=2)
            x0, x1 = x + 20, x + PW - 20
            d.line([x0, y + PP / 2, x1, y + PP / 2], fill=(60, 70, 76), width=6)
            for j in range(21):
                tx = x0 + (x1 - x0) * j / 20; big = j in (0, 10, 20)
                d.line([tx, y + PP - (16 if big else 10), tx, y + PP - 4], fill=AMBER if j == 10 else mix(BODY, PRINT, 0.7 if big else 0.35), width=2 if big else 1)
            for lab, fx in (("L", 0), ("C", 0.5), ("R", 1)):
                text_c(d, x0 + (x1 - x0) * fx, y + PP + 12, lab, font(13), PRINT)
        elif k == "legend":
            _, x, y, lines = item
            mono = "DejaVuSansMono.ttf" if os.path.exists("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf") else "DejaVuSans.ttf"
            for j, ln in enumerate(lines): d.text((x, y + j * 28), ln, font=font(15, mono), fill=PRINT_DIM if j == 3 else PRINT)
        elif k == "cap":
            _, cx, cy, cap = item
            text_c(d, cx, cy, cap, font(11, "DejaVuSans.ttf"), PRINT)
    return im

def build():
    if os.path.isdir(SKIN_DIR): shutil.rmtree(SKIN_DIR)
    os.makedirs(OUT)
    defs = []
    for tab in TABS:
        bgname = f"ds_bg_{tab.lower()}.png"
        IMAGES[bgname] = background(tab)
        comps = [comp("Background", "Image", {"version": 2, "imageType": "Regular", "colour": "0", "image": bgname}, bounds((0, 0, W, H)))]
        for pl in sorted(PLACED[tab], key=lambda q: 1 if q["touch"] else 0):     # read-outs under, touch controls on top
            comps.append(comp(pl["name"], pl["dkey"], {"version": 1, "handleName": "Data"},
                              bounds((pl["x"], pl["y"], pl["w"], pl["h"]), focus="Yes" if pl["touch"] else "No", show="Hide" if pl["touch"] else "Show"),
                              {"version": 1, "map": [{"key": "Data", "value": f"Parameter {pl['param']}"}]}))
        DEFS[f"DS|{tab}"] = definition([], comps, "ff18191e")
    for k, v in DEFS.items(): defs.append({"key": k, "value": v})
    tabs = [{"version": 3, "tabName": t, "fnKeyIndex": i, "fnKeySubIndex": 0, "qlinkBoundsData": ["0 0 0 0"],
             "componentName": f"DS|{t}", "initialSize": f"0 0 {W} {H}", "scale": 1.0} for i, t in enumerate(TABS)]
    tui = {"pageData": {"version": 1,
        "componentDefinitions": {"version": 2, "importFiles": ["/usr/share/Akai/Content/Synths/Generic/Generic Knob Overlay.json",
                                                                "/usr/share/Akai/Content/Synths/Generic/Generic Menu Overlay.json"],
                                 "localComponentDefinitions": defs},
        "info": {"version": 1, "type": "CompleteDescription"}, "tabs": tabs}}
    json.dump(tui, open(os.path.join(OUT, "TUI.json"), "w"), indent=2)
    qmap = lambda keys: {f"Q-Link {i + 1}": P[k] for i, k in enumerate(keys)}
    q = {"version": 4, "info": {"version": 1, "type": "CompleteDescription"},
         "Screen Mode Q-Links": {"version": 4, "map": [{"Tab": i + 1, "SubTab": 1, "Bank Direction": "Column", "Q-Links": qmap(QL[t])} for i, t in enumerate(TABS)]},
         "Program Mode Q-Links": qmap(QL["UTILITY"])}
    for fn in ("Q-Links.json", "Q-Links - 8by1.json"): json.dump(q, open(os.path.join(OUT, fn), "w"), indent=2)
    total = 0
    for name, im in IMAGES.items():
        im.save(os.path.join(OUT, name), optimize=True); total += im.size[0] * im.size[1] * 4
    open(os.path.join(SKIN_DIR, "version.xml"), "w").write(
        "<?xml version='1.0' encoding='utf-8'?>\n<plugincontent version=\"1.0\">\n\t<identifier>scratchlab.vst.daflip</identifier>\n"
        "\t<version>1.0.0.0</version>\n</plugincontent>\n")
    print(f"skin written to {SKIN_DIR}: {len(IMAGES) + 2} images, {total / 1e6:.1f} MB decoded")


# ---------- preview (what the screen should look like, drawn from the same layout) ----------
def preview(outdir):
    os.makedirs(outdir, exist_ok=True)
    vals = {"invl": 0, "invr": 1, "dc": 1, "mono": 0, "msenc": 0, "bassmono": 1, "mute": 0, "bypass": 0,
            "corr": 0.86, "level": 0.8, "isopos": 0.8}
    txt = {"inmode": "Stereo", "width": "100 %", "basshz": "120 Hz", "gain": "+0.0 dB", "pan": "C", "listen": "Normal",
           "isomode": "Keep", "isopos": "R 60", "isowidth": "20 %", "isosoft": "10 %", "isosmooth": "30 %", "isolo": "20 Hz", "isohi": "20 kHz",
           "info": "ISOLATE R 60  width 20 %  20 Hz-20 kHz  (46 ms delay)"}
    inv = {v: k for k, v in P.items()}
    cache = {}
    def im_(n):
        if n not in cache: cache[n] = Image.open(os.path.join(OUT, n)).convert("RGBA")
        return cache[n]
    sheets = []
    for tab in TABS:
        im = im_(f"ds_bg_{tab.lower()}.png").copy(); d = ImageDraw.Draw(im)
        for pl in PLACED[tab]:
            x, y, w, h = int(pl["x"]), int(pl["y"]), int(pl["w"]), int(pl["h"]); key = inv[pl["param"]]; k = pl["kind"]
            if k == "corr":
                fr = round(vals["corr"] * NUMFRAMES)
                for k2 in range(CN): im.alpha_composite(im_(f"sp_corr{k2}.png").crop((0, fr * CP, CP, fr * CP + CP)), (x + k2 * CP, y))
            elif k == "meter":
                fr = round(vals["level"] * NUMFRAMES)
                for k2 in range(MN): im.alpha_composite(im_(f"ds_meter{k2}.png").crop((0, fr * MP, MP, fr * MP + MP)), (x + k2 * MP, y))
            elif k == "pos":
                fr = round(vals["isopos"] * NUMFRAMES)
                for k2 in range(PN): im.alpha_composite(im_(f"sp_pos{k2}.png").crop((0, fr * PP, PP, fr * PP + PP)), (x + k2 * PP, y + PLAB))
                text_c(d, x + w / 2, y + 11, txt["isopos"], font(14), LCD_TXT)
            elif k in ("key", "bigkey"):
                im.alpha_composite(im_(f"ds_key_{'on' if vals.get(key, 0) >= 0.5 else 'off'}.png"), (x, y))
            elif k in ("box", "text"):
                s = txt[key].upper() if k == "box" else txt[key]
                size = 15 if k == "box" else int(pl["extra"] * 0.8); f = font(size)
                while d.textlength(s, font=f) > w - 8 and size > 7: size -= 1; f = font(size)
                text_c(d, x + w / 2, y + h / 2, s, f, LCD_TXT)
        path = os.path.join(outdir, f"skin-preview-{tab.lower()}.png")
        im.convert("RGB").save(path); sheets.append(im.convert("RGB")); print("preview:", path)
    sheet = Image.new("RGB", (W, H * len(sheets) + 10 * (len(sheets) - 1)), (0, 0, 0))
    for i, s in enumerate(sheets): sheet.paste(s, (0, i * (H + 10)))
    sheet.resize((sheet.size[0] // 2, sheet.size[1] // 2), Image.LANCZOS).save(os.path.join(outdir, "skin-preview-all.png"))

if __name__ == "__main__":
    build()
    if len(sys.argv) > 1: preview(sys.argv[1])
